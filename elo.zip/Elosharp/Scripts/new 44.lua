if myHero.charName ~= "Lulu" then return end
require 'VPrediction'
local ScriptVersion = "0.1"
local LeagueVersion = "7.22"
local currentVersion = 0.1

local SACLoaded, MMALoaded = nil,nil
local SACLoaded, MMALoaded = nil,nil
local qDelay, qWidth, qRange, qSpeed = 0.2, 50, 925, 1600
local qRange2 = 850
local qExtended = 1800
local eRange, eDelay = 650, 0.2
local wRange, wDelay = 650, 0.2
local rRange, rDelay, rRadius = 900, 0.2, 200

function OnLoad()
	PrintChat("<font color=\"#33CC99\"><b>EloSharp Lulu by gReY </b></font>"..currentVersion.."<font color=\"#33CC99\"><b> Loaded</b></font>")
	PrintChat("<font color=\"#33CC99\"><b>Report any problem by pm to gReY on Disocrd</b></font>")
	DetectOrbwalker()
	minionAlly = minionManager(MINION_ALLY, 925, myHero, MINION_SORT_HEALTH_DEC)
	minionEnemy = minionManager(MINION_ENEMY, 1100, myHero, MINION_SORT_HEALTH_DEC)
	JungleMinions = minionManager(MINION_JUNGLE, 1200, myHero, MINION_SORT_MAXHEALTH_DEC)
	Menu()
end
function DetectOrbwalker()
	if _G.Reborn_Loaded then
		PrintChat("gReYLulu : SAC Detected")
		SACLoaded = true
    end
end

function OnTick()
	minionAlly:update()
	minionEnemy:update()
	JungleMinions:update()

	QREADY = (myHero:CanUseSpell(_Q) == READY)
	WREADY = (myHero:CanUseSpell(_W) == READY)
	EREADY = (myHero:CanUseSpell(_E) == READY)
	RREADY = (myHero:CanUseSpell(_R) == READY)
	
	if luluCFG.combo.eConfig.autoE then
		autoE()
	end
	if luluCFG.combo.wConfig.autoW then
		autoW()
	end
	if luluCFG.combo.rConfig.autoUlt then
		autoR()
	end
end
function Menu()
	VP = VPrediction()
	luluCFG = scriptConfig("EloSharp Lulu", "LKQ")
	
		luluCFG:addSubMenu("--["..myHero.charName.."]-- Combo", "combo")
			--luluCFG.combo:addSubMenu("Q Spell config", "qConfig")
			--	luluCFG.combo.qConfig:addParam("qUse", "Use Q in combo", SCRIPT_PARAM_ONOFF, true)
			luluCFG.combo:addSubMenu("W Spell config", "wConfig")
				for i ,ally in pairs (GetAllyHeroes()) do
					luluCFG.combo.wConfig:addParam(ally.charName, ally.charName, SCRIPT_PARAM_ONOFF, true)
				end
				luluCFG.combo.wConfig:addParam("autoW", "Auto W ally/self low hp", SCRIPT_PARAM_ONKEYTOGGLE, false, GetKey("p"))
				luluCFG.combo.wConfig:addParam("hpPercent", "% hp left", SCRIPT_PARAM_SLICE, 20, 0, 101, 0)
				--luluCFG.combo.wConfig:addParam("manaPercent", "% mana left", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			luluCFG.combo:addSubMenu("E Spell config", "eConfig")
				for i ,ally in pairs (GetAllyHeroes()) do
					luluCFG.combo.eConfig:addParam(ally.charName, ally.charName, SCRIPT_PARAM_ONOFF, true)
				end
				luluCFG.combo.eConfig:addParam("autoE", "Auto E ally/self low hp", SCRIPT_PARAM_ONKEYTOGGLE, false, GetKey("p"))
				luluCFG.combo.eConfig:addParam("hpPercent", "% hp left", SCRIPT_PARAM_SLICE, 20, 0, 101, 0)
			--	luluCFG.combo.eConfig:addParam("manaPercent", "% mana left", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			luluCFG.combo:addSubMenu("R Spell config", "rConfig")
				luluCFG.combo.rConfig:addParam("rUse", "Use R in combo", SCRIPT_PARAM_ONOFF, true)
				for i ,ally in pairs (GetAllyHeroes()) do
					luluCFG.combo.rConfig:addParam(ally.charName, ally.charName, SCRIPT_PARAM_ONOFF, true)
				end
				luluCFG.combo.rConfig:addParam("EnemyNo", "Min enemy in range", SCRIPT_PARAM_SLICE, 2, 1, 5, 0)
				luluCFG.combo.rConfig:addParam("autoUlt", "Auto Ult ally/self low hp", SCRIPT_PARAM_ONKEYTOGGLE, false, GetKey("p"))
				luluCFG.combo.rConfig:addParam("hpPercent", "% hp left", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			luluCFG.combo:addParam("comboKey", "Combo key", SCRIPT_PARAM_ONKEYDOWN, false, string.byte(" "))
	
				
			if SACLoaded == true then
				luluCFG:addParam("qqq", "SAC Detected", SCRIPT_PARAM_INFO, "")
			end
end
function autoW()
	for i, ally in ipairs(GetAllyHeroes()) do
		if luluCFG.combo.wConfig[ally.charName] then
			
			if GetDistance(ally) < wRange and EnemyNear(1800, ally) > 0 and WREADY and HpCheck(ally, luluCFG.combo.wConfig.hpPercent) then
				CastSpell(_W, ally)
			
			end
		end
	end
	--if EnemyNear(900, myHero) > 0 and WREADY and HpCheck(myHero, luluCFG.combo.wConfig.hpPercent) then
	--	CastSpell(_W, myHero)
	--end
end
function autoE()
	for i, ally in ipairs(GetAllyHeroes()) do
		if luluCFG.combo.eConfig[ally.charName] then
			if GetDistance(ally) < eRange and EnemyNear(1800, ally) > 0 and EREADY and HpCheck(ally, luluCFG.combo.eConfig.hpPercent) then
				CastSpell(_E, ally)
			
			end
		end
	end
	--if EnemyNear(900, myHero) > 0 and EREADY and HpCheck(myHero, luluCFG.combo.eConfig.hpPercent) then
	--	CastSpell(_E, myHero)
	--end
end
function autoR()
	for i, ally in ipairs(GetAllyHeroes()) do
		if luluCFG.combo.rConfig[ally.charName] then
			
			if GetDistance(ally) < rRange and EnemyNear(800, ally) > 0 and RREADY and HpCheck(ally, luluCFG.combo.rConfig.hpPercent) then
				CastSpell(_R, ally)
			
			end
		end
	end
	--if EnemyNear(800, myHero) > 0 and RREADY and HpCheck(myHero, luluCFG.combo.rConfig.hpPercent) then
		--CastSpell(_R, ally)
--end
end
function EnemyNear(range, unit)
    local Enemies = 0
    for _, enemy in ipairs(GetEnemyHeroes()) do
        if ValidTarget(enemy) and GetDistance(enemy, unit) < (range or math.huge) then
            Enemies = Enemies + 1
        end
    end
    return Enemies
end
function ManaCheck(unit, ManaValue)
	if unit.mana < (unit.maxMana * (ManaValue/100))
		then return true
	else
		return false
	end
end
function HpCheck(unit, HealthValue)
	if unit.health < (unit.maxHealth * (HealthValue/100))
		then return true
	else
		return false
	end
end
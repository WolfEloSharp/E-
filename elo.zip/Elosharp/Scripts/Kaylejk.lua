--[[	Kayle Helper by HeX 1.2.3  ]]--

if myHero.charName ~= "Kayle" then return end
local range = 650
local wBuffer = 400 --Wont use W unless they are this far away. 400 by default.
local aRange = 525
local ignite = nil
local lastBasicAttack = 0
local swing = 0
local startAttackSpeed = 0.625
local nextTick = 0
local QREADY, WREADY, EREADY, RREADY  = false, false, false, false
local DFGREADY, BRKREADY, HXGREADY, BWCREADY, STDREADY = false, false, false, false, false
local DFGSlot, BRKSlot, HXGSlot, BWCSlot, STDSlot = nil, nil, nil, nil, nil

function OnLoad()
	PrintChat("<font color='#CCCCCC'> >> Kayle Helper 1.2.3 loaded! <<</font>")
	KHConfig = scriptConfig("Kayle Helper", "KayleHelper")
	KHConfig:addParam("scriptActive", "Combo", SCRIPT_PARAM_ONKEYDOWN, false, 32)
	KHConfig:addParam("Harass", "Harass", SCRIPT_PARAM_ONKEYDOWN, false, 65)
	KHConfig:addParam("autoignite", "Ignite when Killable", SCRIPT_PARAM_ONOFF, true)
	KHConfig:addParam("attacks", "Use auto attacks", SCRIPT_PARAM_ONOFF, true)
	KHConfig:addParam("movement", "Basic Orb Walking", SCRIPT_PARAM_ONOFF, true)
	KHConfig:addParam("drawcirclesSelf", "Draw Circles - Self", SCRIPT_PARAM_ONOFF, false)
	KHConfig:addParam("drawcirclesEnemy", "Draw Circles - Enemy", SCRIPT_PARAM_ONOFF, false)
	KHConfig:permaShow("scriptActive")
	KHConfig:permaShow("Harass")
	ts = TargetSelector(TARGET_LOW_HP, range+50, DAMAGE_MAGIC)
	ts.name = "Kayle"
	KHConfig:addTS(ts)
	
	lastBasicAttack = os.clock()
	
	if myHero:GetSpellData(SUMMONER_1).name:find("SummonerDot") then ignite = SUMMONER_1
		elseif myHero:GetSpellData(SUMMONER_2).name:find("SummonerDot") then ignite = SUMMONER_2
	end
end

function OnProcessSpell(unit, spell)
	if unit.isMe and (spell.name:find("Attack") ~= nil) then
		swing = 1
		lastBasicAttack = os.clock() 
	end
end 

function OnTick()
	ts:update()
	AttackDelay = 1/(myHero.attackSpeed*startAttackSpeed)
	if swing == 1 and os.clock() > lastBasicAttack + AttackDelay then
		swing = 0
	end
	
	DFGSlot, BRKSlot, HXGSlot, BWCSlot, STDSlot = GetInventorySlotItem(3153), GetInventorySlotItem(3128), GetInventorySlotItem(3146), GetInventorySlotItem(3144), GetInventorySlotItem(3131)
	DFGREADY = (DFGSlot ~= nil and myHero:CanUseSpell(DFGSlot) == READY)
	BRKREADY = (BRKSlot ~= nil and myHero:CanUseSpell(BRKSlot) == READY)
	HXGREADY = (HXGSlot ~= nil and myHero:CanUseSpell(HXGSlot) == READY)
	BWCREADY = (BWCSlot ~= nil and myHero:CanUseSpell(BWCSlot) == READY)
	STDREADY = (STDSlot ~= nil and myHero:CanUseSpell(STDSlot) == READY)
	IREADY = (ignite ~= nil and myHero:CanUseSpell(ignite) == READY)
	QREADY = (myHero:CanUseSpell(_Q) == READY)
	WREADY = (myHero:CanUseSpell(_W) == READY)
	EREADY = (myHero:CanUseSpell(_E) == READY)
	RREADY = (myHero:CanUseSpell(_R) == READY)
	
	--[[	Auto Ignite	]]--
	if KHConfig.autoignite then    
		if IREADY then
			local ignitedmg = 0    
			for i = 1, heroManager.iCount, 1 do
				local enemyhero = heroManager:getHero(i)
				if ValidTarget(enemyhero,600) then
					ignitedmg = 50 + 20 * myHero.level
					if enemyhero.health <= ignitedmg then
						CastSpell(ignite, enemyhero)
					end
				end
			end
		end
	end
	
	--[[	Harass	]]--
	if ts.target ~= nil and KHConfig.Harass  then
		if QREADY and GetDistance(ts.target) < range then
			CastSpell(_Q, ts.target)
		end
	end  

	--[[	Basic Combo	]]--
	if ts.target ~= nil and KHConfig.scriptActive then
		--[[	Items	]]--
		if GetDistance(ts.target) < 600 then
			if DFGREADY then CastSpell(DFGSlot, ts.target) end
			if BRKREADY then CastSpell(BRKSlot, ts.target) end
			if HXGREADY then CastSpell(HXGSlot, ts.target) end
			if BWCREADY then CastSpell(BWCSlot, ts.target) end
			if STDREADY then CastSpell(STDSlot) end
		end
		--[[	Abilities	]]--
		if QREADY and GetDistance(ts.target) < range then
			CastSpell(_Q, ts.target)
		end
		if EREADY and GetDistance(ts.target) < aRange then
			CastSpell(_E)
		end
		if WREADY and GetDistance(ts.target) > wBuffer then
			CastSpell(_W, myHero)
		end
		--[[	Attacks	]]--
		if swing == 0 and KHConfig.attacks then
			if GetDistance(ts.target) < range and GetTickCount() > nextTick then
				myHero:Attack(ts.target)
				nextTick = GetTickCount()
			end
			elseif swing == 1 and KHConfig.movement and KHConfig.attacks and GetTickCount() > (nextTick + 250) then
				myHero:MoveTo(mousePos.x, mousePos.z)
		end
	end
end

function OnDraw()	
	if KHConfig.drawcirclesSelf and not myHero.dead then
		DrawCircle(myHero.x, myHero.y, myHero.z, 650, 0xFF80FF00)
	end
	if KHConfig.drawcirclesEnemy and ts.target ~= nil then
		for j=0, 10 do
			DrawCircle(ts.target.x, ts.target.y, ts.target.z, 40 + j*1.5, 0x00FF00)
		end
	end
end
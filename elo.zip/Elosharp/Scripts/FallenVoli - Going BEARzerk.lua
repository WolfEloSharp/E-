--[[ 
  ______    _ _            _____           _                          
 |  ____|  | | |          |  __ \         | |                         
 | |__ __ _| | | ___ _ __ | |__) |__ _ __ | |_ __ _  __ _  ___  _ __  
 |  __/ _` | | |/ _ \ '_ \|  ___/ _ \ '_ \| __/ _` |/ _` |/ _ \| '_ \ 
 | | | (_| | | |  __/ | | | |  |  __/ | | | || (_| | (_| | (_) | | | |
 |_|  \__,_|_|_|\___|_| |_|_|   \___|_| |_|\__\__,_|\__, |\___/|_| |_|
                                                     __/ |            
                                                    |___/             
-- Going BEARzerk BETA
]]

local scriptVersion = 0.2
local autoUpdate = true
local loadOrbWalker = true

assert(load(Base64Decode("G0x1YVIAAQQEBAgAGZMNChoKAAAAAAAAAAAAAQQfAAAAAwAAAEQAAACGAEAA5QAAAJ1AAAGGQEAA5UAAAJ1AAAGlgAAACIAAgaXAAAAIgICBhgBBAOUAAQCdQAABhkBBAMGAAQCdQAABhoBBAOVAAQCKwICDhoBBAOWAAQCKwACEhoBBAOXAAQCKwICEhoBBAOUAAgCKwACFHwCAAAsAAAAEEgAAAEFkZFVubG9hZENhbGxiYWNrAAQUAAAAQWRkQnVnc3BsYXRDYWxsYmFjawAEDAAAAFRyYWNrZXJMb2FkAAQNAAAAQm9sVG9vbHNUaW1lAAQQAAAAQWRkVGlja0NhbGxiYWNrAAQGAAAAY2xhc3MABA4AAABTY3JpcHRUcmFja2VyAAQHAAAAX19pbml0AAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAoAAABzZW5kRGF0YXMABAsAAABHZXRXZWJQYWdlAAkAAAACAAAAAwAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAcAAAB1bmxvYWQAAAAAAAEAAAABAQAAAAAAAAAAAAAAAAAAAAAEAAAABQAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAkAAABidWdzcGxhdAAAAAAAAQAAAAEBAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAAAAQAEDQAAAEYAwACAAAAAXYAAAUkAAABFAAAATEDAAMGAAABdQIABRsDAAKUAAADBAAEAXUCAAR8AgAAFAAAABA4AAABTY3JpcHRUcmFja2VyAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAUAAABsb2FkAAQMAAAARGVsYXlBY3Rpb24AAwAAAAAAQHpAAQAAAAYAAAAHAAAAAAADBQAAAAUAAAAMAEAAgUAAAB1AgAEfAIAAAgAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAgAAAB3b3JraW5nAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAEBAAAAAAAAAAAAAAAAAAAAAAAACAAAAA0AAAAAAAYyAAAABgBAAB2AgAAaQEAAF4AAgEGAAABfAAABF0AKgEYAQQBHQMEAgYABAMbAQQDHAMIBEEFCAN0AAAFdgAAACECAgUYAQQBHQMEAgYABAMbAQQDHAMIBEMFCAEbBQABPwcICDkEBAt0AAAFdgAAACEAAhUYAQQBHQMEAgYABAMbAQQDHAMIBBsFAAA9BQgIOAQEARoFCAE/BwgIOQQEC3QAAAV2AAAAIQACGRsBAAIFAAwDGgEIAAUEDAEYBQwBWQIEAXwAAAR8AgAAOAAAABA8AAABHZXRJbkdhbWVUaW1lcgADAAAAAAAAAAAECQAAADAwOjAwOjAwAAQGAAAAaG91cnMABAcAAABzdHJpbmcABAcAAABmb3JtYXQABAYAAAAlMDIuZgAEBQAAAG1hdGgABAYAAABmbG9vcgADAAAAAAAgrEAEBQAAAG1pbnMAAwAAAAAAAE5ABAUAAABzZWNzAAQCAAAAOgAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAATAAAAAAAIKAAAAAEAAABGQEAAR4DAAIEAAAAhAAiABkFAAAzBQAKAAYABHYGAAVgAQQIXgAaAR0FBAhiAwQIXwAWAR8FBAhkAwAIXAAWARQGAAFtBAAAXQASARwFCAoZBQgCHAUIDGICBAheAAYBFAQABTIHCAsHBAgBdQYABQwGAAEkBgAAXQAGARQEAAUyBwgLBAQMAXUGAAUMBgABJAYAAIED3fx8AgAANAAAAAwAAAAAAAPA/BAsAAABvYmpNYW5hZ2VyAAQLAAAAbWF4T2JqZWN0cwAECgAAAGdldE9iamVjdAAABAUAAAB0eXBlAAQHAAAAb2JqX0hRAAQHAAAAaGVhbHRoAAQFAAAAdGVhbQAEBwAAAG15SGVybwAEEgAAAFNlbmRWYWx1ZVRvU2VydmVyAAQGAAAAbG9vc2UABAQAAAB3aW4AAAAAAAMAAAAAAAEAAQEAAAAAAAAAAAAAAAAAAAAAFAAAABQAAAACAAICAAAACkAAgB8AgAABAAAABAoAAABzY3JpcHRLZXkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABUAAAACAAUKAAAAhgBAAMAAgACdgAABGEBAARfAAICFAIAAjIBAAQABgACdQIABHwCAAAMAAAAEBQAAAHR5cGUABAcAAABzdHJpbmcABAoAAABzZW5kRGF0YXMAAAAAAAIAAAAAAAEBAAAAAAAAAAAAAAAAAAAAABYAAAAlAAAAAgATPwAAAApAAICGgEAAnYCAAAqAgICGAEEAxkBBAAaBQQAHwUECQQECAB2BAAFGgUEAR8HBAoFBAgBdgQABhoFBAIfBQQPBgQIAnYEAAcaBQQDHwcEDAcICAN2BAAEGgkEAB8JBBEECAwAdggABFgECAt0AAAGdgAAACoCAgYaAQwCdgIAACoCAhgoAxIeGQEQAmwAAABdAAIAKgMSHFwAAgArAxIeGQEUAh4BFAQqAAIqFAIAAjMBFAQEBBgBBQQYAh4FGAMHBBgAAAoAAQQIHAIcCRQDBQgcAB0NAAEGDBwCHw0AAwcMHAAdEQwBBBAgAh8RDAFaBhAKdQAACHwCAACEAAAAEBwAAAGFjdGlvbgAECQAAAHVzZXJuYW1lAAQIAAAAR2V0VXNlcgAEBQAAAGh3aWQABA0AAABCYXNlNjRFbmNvZGUABAkAAAB0b3N0cmluZwAEAwAAAG9zAAQHAAAAZ2V0ZW52AAQVAAAAUFJPQ0VTU09SX0lERU5USUZJRVIABAkAAABVU0VSTkFNRQAEDQAAAENPTVBVVEVSTkFNRQAEEAAAAFBST0NFU1NPUl9MRVZFTAAEEwAAAFBST0NFU1NPUl9SRVZJU0lPTgAECwAAAGluZ2FtZVRpbWUABA0AAABCb2xUb29sc1RpbWUABAYAAABpc1ZpcAAEAQAAAAAECQAAAFZJUF9VU0VSAAMAAAAAAADwPwMAAAAAAAAAAAQJAAAAY2hhbXBpb24ABAcAAABteUhlcm8ABAkAAABjaGFyTmFtZQAECwAAAEdldFdlYlBhZ2UABA4AAABib2wtdG9vbHMuY29tAAQXAAAAL2FwaS9ldmVudHM/c2NyaXB0S2V5PQAECgAAAHNjcmlwdEtleQAECQAAACZhY3Rpb249AAQLAAAAJmNoYW1waW9uPQAEDgAAACZib2xVc2VybmFtZT0ABAcAAAAmaHdpZD0ABA0AAAAmaW5nYW1lVGltZT0ABAgAAAAmaXNWaXA9AAAAAAACAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAmAAAAKgAAAAMACiEAAADGQEAAAYEAAN2AAAHHwMAB3YCAAArAAIDHAEAAzADBAUABgACBQQEA3UAAAscAQADMgMEBQcEBAIABAAHBAQIAAAKAAEFCAgBWQYIC3UCAAccAQADMgMIBQcECAIEBAwDdQAACxwBAAMyAwgFBQQMAgYEDAN1AAAIKAMSHCgDEiB8AgAASAAAABAcAAABTb2NrZXQABAgAAAByZXF1aXJlAAQHAAAAc29ja2V0AAQEAAAAdGNwAAQIAAAAY29ubmVjdAADAAAAAAAAVEAEBQAAAHNlbmQABAUAAABHRVQgAAQSAAAAIEhUVFAvMS4wDQpIb3N0OiAABAUAAAANCg0KAAQLAAAAc2V0dGltZW91dAADAAAAAAAAAAAEAgAAAGIAAwAAAPyD15dBBAIAAAB0AAQKAAAATGFzdFByaW50AAQBAAAAAAQFAAAARmlsZQAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAAAAAAAAAAAAAAAAAAA="), nil, "bt", _ENV))()
TrackerLoad("0tur3tVMWSg8qMIA")

if myHero.charName ~= "Volibear" then return end

local Q, W, E, R  = {}, {}, {}, {}
local slot = {"Q", "W", "E", "R"}
local IsReady = function(spell) return myHero:CanUseSpell(spell) == READY end
local myTrueRange = myHero.range + GetDistance(myHero.minBBox)
local reset = false

function OnLoad()	
	Show("loading...")
	Update()
	if GetInGameTimer() < 5 then DelayAction(function() myTrueRange = myHero.range + GetDistance(myHero.minBBox) end, 5 - GetInGameTimer()) end	
	Volibear()
	LoadMenu()
	if loadOrbWalker then LoadOrbWalker() end
end

function OnTick()
	Target()
	if Config.Keys.Flee then
		Volibear:Flee()
	elseif target and Config.Keys.Combo then
		Volibear:Combo()
	elseif target and Config.Keys.Harass then
		Volibear:Harass()
	end	
end

function OnDraw()
	if myHero.dead then return end
	if Config.Draw.MyRange then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, myTrueRange, 1, 0xff00ff00)
	end
	if Config.Draw.Target and target then
		DrawCircle3D(target.x, target.y, target.z, target.range + GetDistance(target, target.minBBox), 1, 0xffff0000)
	end
end

function LoadMenu() 
	Config = scriptConfig("FallenVoli", "FallenVoli")
	Config:addSubMenu("Key Settings", "Keys")
	Config:addSubMenu("AutoKill", "AutoKill")	
	Config:addSubMenu("Combo", "Combo")	
	Config.Keys:addParam("Combo", "Combo", SCRIPT_PARAM_ONKEYDOWN, false, 32)
	Config:addSubMenu("Harass", "Harass")
	Config.Keys:addParam("Harass", "Harass", SCRIPT_PARAM_ONKEYDOWN, false, 67)
	Config:addSubMenu("Interupt", "Interupt")
	Config:addSubMenu("Flee", "Flee")	
	Config.Keys:addParam("Flee", "Flee", SCRIPT_PARAM_ONKEYDOWN, false, 71)
	Config:addSubMenu("Draw", "Draw")
	if loadOrbWalker then Config:addSubMenu("OrbWalker", "OrbWalker") end
	Config.Draw:addParam("MyRange", "my range", SCRIPT_PARAM_ONOFF, false)				
	Config.Draw:addParam("Target", "target range", SCRIPT_PARAM_ONOFF, true)
	Config:addSubMenu("Misc", "Misc")
	Config:addParam("version","____________________________________________", 5, " v "..scriptVersion)
	Config:addParam("author","by FallenPentagon", 5, "")
	Volibear:Menu()
	AddDrawCallback(function() Volibear:Draw() end)
	AddTickCallback(function() Volibear:AutoKill() end)
	AddProcessAttackCallback(function(unit, spell) Volibear:ProcessAttack(unit, spell) end)
	AddProcessSpellCallback(function(unit, spell) Volibear:ProcessSpell(unit, spell) end)
	AddRemoveBuffCallback(function(unit, buff) Volibear:RemoveBuff(unit, buff) end)
	AddApplyBuffCallback(function(source, unit, buff) Volibear:ApplyBuff(source, unit, buff) end)
end

function LoadOrbWalker()  
	if not _G.UOLloaded then     
		if FileExist(LIB_PATH.."UOL.lua") then
			require "UOL" 
			UOL:AddToMenu(Config.OrbWalker)
			isUOL = true
   		else
    		Show("Couldnt find UOL.lua, downloading now...")
    		DownloadFile("https://raw.githubusercontent.com/nebelwolfi/BoL/master/Common/UOL.lua", LIB_PATH.."UOL.lua", function() Show("Downloaded UOL.lua successfully, press F9 twice to reload") end)
    		return
    	end
    end
end

function Update()
	local source = "www.FallenPentagon.com"
	local path = "/BolScripts/FallenVoli.version"
	local url = "http://"..source.."/BolScripts/FallenVoli.lua"
	if autoUpdate and tonumber(GetWebResult(source, path)) > scriptVersion then
		Show("Newer version found, don't press F9 while its Downloading...")
		DownloadFile(url, SCRIPT_PATH..GetCurrentEnv().FILE_NAME, function() Show("Downloaded successfully, press F9 twice to reload") end)
	else
		Show("Successfully loaded v"..scriptVersion)
	end
end

function Target()
	ts:update()
   	if isUOL and UOL:GetTarget() and UOL:GetTarget().type == myHero.type then
    	target = UOL:GetTarget()
    else
    	target = ts.target
    end
    if target and isUOL then UOL:ForceTarget(target) end
end

function AddTS(range, type)
	ts = TargetSelector(TARGET_LESS_CAST_PRIORITY, range, type, false)
	ts.name = "Target Selector"
	Config.Misc:addTS(ts)
end

function Show(text)
	print("<font color = \"#6F3A9C\">[FallenVoli]<font color = \"#ffff33\"> "..text)
end

function DrawOverheadHUD(unit, framePos, newDamage, str, color)
    local barPos = Point(framePos.x, framePos.y - 18)
    healthMissing = (unit.maxHealth - unit.health)
    offset = -105 * (newDamage/unit.maxHealth + healthMissing/unit.maxHealth)
    barPos = Point(framePos.x + 105, framePos.y - 26)
    if offset <= (-105) then
    	DrawText(str, 40, barPos.x + - 100, barPos.y - 23, color)
    	DrawText("W will kill!", 20, barPos.x + - 100, barPos.y - 40, color)
    else
    	DrawText(str, 14, barPos.x + offset - 5, barPos.y - 18, color)
    	DrawRectangle(barPos.x + offset - 1, barPos.y, 2, 15, color)
	end
end

function GetUnitName(unit)
	if unit.charName == "MonkeyKing" then
		return "Wukong"
	end
	return unit.charName
end

function GetAbilityFramePos(unit) -- credits to Xivia and Jorj
    local barPos = GetUnitHPBarPos(unit)
    local barOffset = GetUnitHPBarOffset(unit)
    do
        local t = {
            ["Darius"] = - 0.05,
            ["Renekton"] = - 0.05,
            ["Sion"] = - 0.05,
            ["Thresh"] = - 0.03,
        }
        barOffset.x = t[unit.charName] or barOffset.x
        local r = {
            ["XinZhao"] = 1,
            ["Velkoz"] = - 2.65,
            ["Darius"] = - 0.33,           
        }
        barOffset.y = r[unit.charName] or barOffset.y
    end
    return D3DXVECTOR2(barPos.x + barOffset.x * 150 - 70, barPos.y + barOffset.y * 50 + 13)
end

cSpellData = {
    	["Caitlyn"] = {true, spell = {{name = "Ace in the Hole", slot = 3}}}, 
    	["FiddleSticks"] = {true, spell = {{name = "Drain", slot = 1},
    		{name = "Crowstorm", slot = 3}}},
    	["Galio"] = {true, spell = {{name = "Idol of Durand", slot = 3}}},
    	["Janna"] = {true, spell = {{name = "Requiem", slot = 3}}},
    	["Karthus"] = {true, spell = {{name = "Requiem", slot = 3}}},
    	["Katarina"] = {true, spell = {{name = "Death Lotus", slot = 3}}},
    	["Malzahar"] = {true, spell = {{name = "Nether Grasp", slot = 3}}},
    	["MasterYi"] = {true, spell = {{name = "Meditate", slot = 1}}},
    	["MissFortune"] = {true, spell = {{name = "Bullet Time", slot = 3}}},
    	["Nunu"] = {true, spell = {{name = "Absolute Zero", slot = 3}}},
    	["Pantheon"] = {true, spell = {{name = "Heartseeker Strike", slot = 2},
    		{name = "Grand Skyfall", slot = 3}}},
    	["Twisted Fate"] = {true, spell = {{name = "Gate", slot = 3}}},
    	["Urgot"] = {true, spell = {{name = "Hyper-Kinetic Position Reverser", slot = 3}}},
    	["Warwick"] = {true, spell = {{name = "Infinite Duress", slot = 3}}}
}

class "Volibear"
function Volibear:__init()	
	self.baseHealth = {585, 647, 712, 780, 851, 925, 1002, 1082, 1165, 1251, 1340, 1432, 1527, 1625, 1726, 1830, 1937, 2047}
	Q.active = false
	Q.damage = function() return myHero:GetSpellData(0).level * 30 end
	Q.ms = function() return 1.40 + myHero:GetSpellData(0).level * 0.05 end
	W.damage = function(unit) return myHero:CalcDamage(unit, (myHero:GetSpellData(1).level * 45 + 35 + 0.15 * (myHero.maxHealth - self.baseHealth[myHero.level])) * (1 + (1 - unit.health / unit.maxHealth))) end
	W.range = 400
	E.damage = function() return myHero:GetSpellData(2).level * 45 + 15 + myHero.ap * 0.6 end
	E.range = 425
	R.active = false
	R.damage = function() return myHero:GetSpellData(3).level * 40 + 35 + myHero.ap * 0.3 end
	R.range = 500
end

function Volibear:AutoKill()
	E.range = Config.Misc.ERange
	for _, enemy in pairs(GetEnemyHeroes()) do
		local rDmg = R.active and R.damage() or 0
		if ValidTarget(enemy, E.range) and  enemy.health <= E.damage() and IsReady(2) and Config.AutoKill.UseE then
			CastSpell(2)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg) + myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage) and IsReady(0) and Config.AutoKill.UseQ then
			CastSpell(0)
			myHero:Attack(enemy)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg) + myHero:CalcDamage(enemy, Q.damage() + 2 * myHero.totalDamage) and IsReady(0) and Config.AutoKill.UseQ then
			self:Reset()
			myHero:Attack(enemy)
		elseif ValidTarget(enemy, W.range) and enemy.health <= W.damage(enemy) and IsReady(1) and Config.AutoKill.UseW then
			CastSpell(1, enemy)
		elseif ValidTarget(enemy, E.range) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg + E.damage()) + myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage) and IsReady(2) and Config.AutoKill.UseE and IsReady(0) and Config.AutoKill.UseQ then
			CastSpell(2)
			CastSpell(0)
			myHero:Attack(enemy)
		elseif ValidTarget(enemy, E.range) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg + E.damage()) + myHero:CalcDamage(enemy, Q.damage() + 2 * myHero.totalDamage) and IsReady(2) and Config.AutoKill.UseE and IsReady(0) and Config.AutoKill.UseQ then
			CastSpell(2)
			self:Reset()
			myHero:Attack(enemy)
		elseif ValidTarget(enemy, E.range) and enemy.health <= myHero:CalcMagicDamage(enemy, E.damage()) + W.damage(enemy) and IsReady(2) and Config.AutoKill.UseE and IsReady(1) and Config.AutoKill.UseW then
			CastSpell(2)
			CastSpell(1, enemy)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg) + W.damage(enemy) + myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage) and IsReady(1) and Config.AutoKill.UseW and IsReady(0) and Config.AutoKill.UseQ then
			CastSpell(0)
			myHero:Attack(enemy)
			DelayAction(function() CastSpell(1, enemy) end, 0.1)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg) + W.damage(enemy) + myHero:CalcDamage(enemy, Q.damage() + 2 * myHero.totalDamage) and IsReady(1) and Config.AutoKill.UseW and IsReady(0) and Config.AutoKill.UseQ then
			self:Reset()
			myHero:Attack(enemy)
			DelayAction(function() CastSpell(1, enemy) end, 0.3)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg + E.damage()) + W.damage(enemy) + myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage) and IsReady(1) and Config.AutoKill.UseW and IsReady(0) and Config.AutoKill.UseQ and IsReady(2) and Config.AutoKill.UseE then
			CastSpell(2)
			CastSpell(0)
			myHero:Attack(enemy)
			DelayAction(function() CastSpell(1, enemy) end, 0.5)
		elseif ValidTarget(enemy, myTrueRange) and enemy.health <= myHero:CalcMagicDamage(enemy, rDmg + E.damage()) + W.damage(enemy) + myHero:CalcDamage(enemy, Q.damage() + 2 * myHero.totalDamage) and IsReady(1) and Config.AutoKill.UseW and IsReady(0) and Config.AutoKill.UseQ and IsReady(2) and Config.AutoKill.UseE then
			CastSpell(2)
			self:Reset()
			myHero:Attack(enemy)
			DelayAction(function() CastSpell(1, enemy) end, 1)
		end
	end
end

function Volibear:Combo()
	if ValidTarget(target, myTrueRange) and IsReady(0) and Config.Combo.UseQ == 2 then
		CastSpell(0)
	elseif ValidTarget(target, myTrueRange) and IsReady(0) and Config.Combo.UseQ == 1 and target.ms > myHero.ms then
		self:Reset()
	elseif ValidTarget(target, W.range) and IsReady(1) and Config.Combo.UseW then
		CastSpell(1, target)
	elseif ValidTarget(target, E.range) and IsReady(2) and Config.Combo.UseE then
		CastSpell(2)
	elseif ValidTarget(target, 1000) and GetDistance(target) > myTrueRange and IsReady(0) and Config.Combo.UseQ == 1 and myHero.ms - target.ms < 50 and (GetDistance(target) * (myHero.ms * Q.ms() - target.ms)) >= 2 then
		CastSpell(0)
	end
	if Config.Combo.UseR > 0 and IsReady(3) then 
		local count = 0
		for i, enemy in pairs(GetEnemyHeroes()) do
			if ValidTarget(enemy, R.range) then
				count = count + 1
			end
		end
		if count >= Config.Combo.UseR then
			CastSpell(3)
		end
	end
end

function Volibear:Draw()
	if myHero.dead then return end
	if Config.Draw.WRange then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, W.range, 1, 0xff00ff00)
	end
	if Config.Draw.ERange then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, E.range, 1, 0xff00ff00)
	end
	if Config.Draw.RRange then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, R.range, 1, 0xff00ff00)
	end
	if Config.Draw.WDmg then
		for i, enemy in pairs(GetEnemyHeroes()) do
        	if enemy.visible and not enemy.dead then
            	local framePos = GetAbilityFramePos(enemy)
            	if OnScreen(framePos.x, framePos.y) then
               		DrawOverheadHUD(enemy, framePos, W.damage(enemy), "W", ARGB(255,255,0,255))              
            	end
        	end
    	end
	end
end

function Volibear:Flee()
	myHero:MoveTo(mousePos.x, mousePos.z)
	if Config.Flee.UseQ then
		CastSpell(0)
	end
	if Config.Flee.UseE then
		for _, enemy in pairs(GetEnemyHeroes()) do
			if ValidTarget(enemy, E.range) then
				CastSpell(2)
			end
		end
	end
end

function Volibear:Harass()
	if ValidTarget(target, myTrueRange) and IsReady(0) and Config.Harass.UseQ then
		CastSpell(0, target)
	elseif ValidTarget(target, W.range) and IsReady(1) and Config.Harass.UseW then
		CastSpell(1, target)
	elseif ValidTarget(target, E.range) and IsReady(2) and Config.Harass.UseE then
		CastSpell(2)
	end
end

function Volibear:Menu()
	AddTS(1000, DAMAGE_PHYSICAL)
	Config.AutoKill:addParam("UseQ", "use Q", SCRIPT_PARAM_ONOFF, true)
	Config.AutoKill:addParam("UseW", "use W", SCRIPT_PARAM_ONOFF, true)
	Config.AutoKill:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)
	Config.Combo:addParam("UseQ", "use Q", SCRIPT_PARAM_LIST, 1, {"Smart", "Always", "Never"})
	Config.Combo:addParam("UseW", "use W", SCRIPT_PARAM_ONOFF, false)
	Config.Combo:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)
	Config.Combo:addParam("UseR", "use R", SCRIPT_PARAM_SLICE, 3, 0, 5, 0)
	Config.Draw:addParam("WRange", "W range", SCRIPT_PARAM_ONOFF, true)
	Config.Draw:addParam("ERange", "E range", SCRIPT_PARAM_ONOFF, false)
	Config.Draw:addParam("RRange", "R range", SCRIPT_PARAM_ONOFF, false)
	Config.Draw:addParam("WDmg", "W damage", SCRIPT_PARAM_ONOFF, true)
	Config.Flee:addParam("UseQ", "use Q", SCRIPT_PARAM_ONOFF, true)
	Config.Flee:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)	
	Config.Harass:addParam("UseQ", "use Q", SCRIPT_PARAM_ONOFF, true)
	Config.Harass:addParam("UseW", "use W", SCRIPT_PARAM_ONOFF, true)
	Config.Harass:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)
	Config.Misc:addParam("ERange", "E range", SCRIPT_PARAM_SLICE, 425, 350, 425, 0)
	local spells = false
	for _, enemy in pairs(GetEnemyHeroes()) do
		if cSpellData[GetUnitName(enemy)] then
			spells = true
        	for i = 1, #cSpellData[GetUnitName(enemy)].spell do
            	local spellName = enemy:GetSpellData(cSpellData[GetUnitName(enemy)].spell[i].slot).name
                Config.Interupt:addParam(spellName, GetUnitName(enemy).." | "..slot[cSpellData[GetUnitName(enemy)].spell[i].slot + 1].." | "..cSpellData[GetUnitName(enemy)].spell[i].name, SCRIPT_PARAM_ONOFF, true)	
        	end
        end
    end
    if not spells then
    	Config.Interupt:addParam("info","no supported spells found", 5, "")
    end
end

function Volibear:ProcessAttack(unit, spell)
	if unit and unit.isMe and spell.target == target and spell.name:find("Attack") and IsReady(0) and reset then
		CastSpell(0)
		UOL:ResetAA()
		myHero:Attack(spell.target)
		reset = false
	end
end

function Volibear:ProcessSpell(unit, spell)
	if Config.Interupt[spell.name] and ValidTarget(unit, myTrueRange) and (IsReady(0) or Q.active) then
		CastSpell(0)
		myHero:Attack(unit)
	end
end

function Volibear:ApplyBuff(source, unit, buff)
	if unit and unit.isMe then
		if buff.name:find("Q") then
			Q.active = true
		elseif buff.name:find("rapplicator") then
			R.active = true
		end
	end
end

function Volibear:RemoveBuff(unit, buff)
	if unit and unit.isMe then
		if buff.name:find("Q") then
			Q.active = false
		elseif buff.name:find("rapplicator") then
			R.active = false 
		end
	end
end

function Volibear:Reset()
	reset = true
	DelayAction(function() reset = false end, 2)
end

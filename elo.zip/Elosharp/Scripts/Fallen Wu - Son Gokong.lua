--[[ 
  ______    _ _            _____           _                          
 |  ____|  | | |          |  __ \         | |                         
 | |__ __ _| | | ___ _ __ | |__) |__ _ __ | |_ __ _  __ _  ___  _ __  
 |  __/ _` | | |/ _ \ '_ \|  ___/ _ \ '_ \| __/ _` |/ _` |/ _ \| '_ \ 
 | | | (_| | | |  __/ | | | |  |  __/ | | | || (_| | (_| | (_) | | | |
 |_|  \__,_|_|_|\___|_| |_|_|   \___|_| |_|\__\__,_|\__, |\___/|_| |_|
                                                     __/ |            
                                                    |___/             
-- Son Gokong BETA
]]

local scriptVersion = 0.1
local autoUpdate = true
local loadOrbWalker = true

assert(load(Base64Decode("G0x1YVIAAQQEBAgAGZMNChoKAAAAAAAAAAAAAQQfAAAAAwAAAEQAAACGAEAA5QAAAJ1AAAGGQEAA5UAAAJ1AAAGlgAAACIAAgaXAAAAIgICBhgBBAOUAAQCdQAABhkBBAMGAAQCdQAABhoBBAOVAAQCKwICDhoBBAOWAAQCKwACEhoBBAOXAAQCKwICEhoBBAOUAAgCKwACFHwCAAAsAAAAEEgAAAEFkZFVubG9hZENhbGxiYWNrAAQUAAAAQWRkQnVnc3BsYXRDYWxsYmFjawAEDAAAAFRyYWNrZXJMb2FkAAQNAAAAQm9sVG9vbHNUaW1lAAQQAAAAQWRkVGlja0NhbGxiYWNrAAQGAAAAY2xhc3MABA4AAABTY3JpcHRUcmFja2VyAAQHAAAAX19pbml0AAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAoAAABzZW5kRGF0YXMABAsAAABHZXRXZWJQYWdlAAkAAAACAAAAAwAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAcAAAB1bmxvYWQAAAAAAAEAAAABAQAAAAAAAAAAAAAAAAAAAAAEAAAABQAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAkAAABidWdzcGxhdAAAAAAAAQAAAAEBAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAAAAQAEDQAAAEYAwACAAAAAXYAAAUkAAABFAAAATEDAAMGAAABdQIABRsDAAKUAAADBAAEAXUCAAR8AgAAFAAAABA4AAABTY3JpcHRUcmFja2VyAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAUAAABsb2FkAAQMAAAARGVsYXlBY3Rpb24AAwAAAAAAQHpAAQAAAAYAAAAHAAAAAAADBQAAAAUAAAAMAEAAgUAAAB1AgAEfAIAAAgAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAgAAAB3b3JraW5nAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAEBAAAAAAAAAAAAAAAAAAAAAAAACAAAAA0AAAAAAAYyAAAABgBAAB2AgAAaQEAAF4AAgEGAAABfAAABF0AKgEYAQQBHQMEAgYABAMbAQQDHAMIBEEFCAN0AAAFdgAAACECAgUYAQQBHQMEAgYABAMbAQQDHAMIBEMFCAEbBQABPwcICDkEBAt0AAAFdgAAACEAAhUYAQQBHQMEAgYABAMbAQQDHAMIBBsFAAA9BQgIOAQEARoFCAE/BwgIOQQEC3QAAAV2AAAAIQACGRsBAAIFAAwDGgEIAAUEDAEYBQwBWQIEAXwAAAR8AgAAOAAAABA8AAABHZXRJbkdhbWVUaW1lcgADAAAAAAAAAAAECQAAADAwOjAwOjAwAAQGAAAAaG91cnMABAcAAABzdHJpbmcABAcAAABmb3JtYXQABAYAAAAlMDIuZgAEBQAAAG1hdGgABAYAAABmbG9vcgADAAAAAAAgrEAEBQAAAG1pbnMAAwAAAAAAAE5ABAUAAABzZWNzAAQCAAAAOgAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAATAAAAAAAIKAAAAAEAAABGQEAAR4DAAIEAAAAhAAiABkFAAAzBQAKAAYABHYGAAVgAQQIXgAaAR0FBAhiAwQIXwAWAR8FBAhkAwAIXAAWARQGAAFtBAAAXQASARwFCAoZBQgCHAUIDGICBAheAAYBFAQABTIHCAsHBAgBdQYABQwGAAEkBgAAXQAGARQEAAUyBwgLBAQMAXUGAAUMBgABJAYAAIED3fx8AgAANAAAAAwAAAAAAAPA/BAsAAABvYmpNYW5hZ2VyAAQLAAAAbWF4T2JqZWN0cwAECgAAAGdldE9iamVjdAAABAUAAAB0eXBlAAQHAAAAb2JqX0hRAAQHAAAAaGVhbHRoAAQFAAAAdGVhbQAEBwAAAG15SGVybwAEEgAAAFNlbmRWYWx1ZVRvU2VydmVyAAQGAAAAbG9vc2UABAQAAAB3aW4AAAAAAAMAAAAAAAEAAQEAAAAAAAAAAAAAAAAAAAAAFAAAABQAAAACAAICAAAACkAAgB8AgAABAAAABAoAAABzY3JpcHRLZXkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABUAAAACAAUKAAAAhgBAAMAAgACdgAABGEBAARfAAICFAIAAjIBAAQABgACdQIABHwCAAAMAAAAEBQAAAHR5cGUABAcAAABzdHJpbmcABAoAAABzZW5kRGF0YXMAAAAAAAIAAAAAAAEBAAAAAAAAAAAAAAAAAAAAABYAAAAlAAAAAgATPwAAAApAAICGgEAAnYCAAAqAgICGAEEAxkBBAAaBQQAHwUECQQECAB2BAAFGgUEAR8HBAoFBAgBdgQABhoFBAIfBQQPBgQIAnYEAAcaBQQDHwcEDAcICAN2BAAEGgkEAB8JBBEECAwAdggABFgECAt0AAAGdgAAACoCAgYaAQwCdgIAACoCAhgoAxIeGQEQAmwAAABdAAIAKgMSHFwAAgArAxIeGQEUAh4BFAQqAAIqFAIAAjMBFAQEBBgBBQQYAh4FGAMHBBgAAAoAAQQIHAIcCRQDBQgcAB0NAAEGDBwCHw0AAwcMHAAdEQwBBBAgAh8RDAFaBhAKdQAACHwCAACEAAAAEBwAAAGFjdGlvbgAECQAAAHVzZXJuYW1lAAQIAAAAR2V0VXNlcgAEBQAAAGh3aWQABA0AAABCYXNlNjRFbmNvZGUABAkAAAB0b3N0cmluZwAEAwAAAG9zAAQHAAAAZ2V0ZW52AAQVAAAAUFJPQ0VTU09SX0lERU5USUZJRVIABAkAAABVU0VSTkFNRQAEDQAAAENPTVBVVEVSTkFNRQAEEAAAAFBST0NFU1NPUl9MRVZFTAAEEwAAAFBST0NFU1NPUl9SRVZJU0lPTgAECwAAAGluZ2FtZVRpbWUABA0AAABCb2xUb29sc1RpbWUABAYAAABpc1ZpcAAEAQAAAAAECQAAAFZJUF9VU0VSAAMAAAAAAADwPwMAAAAAAAAAAAQJAAAAY2hhbXBpb24ABAcAAABteUhlcm8ABAkAAABjaGFyTmFtZQAECwAAAEdldFdlYlBhZ2UABA4AAABib2wtdG9vbHMuY29tAAQXAAAAL2FwaS9ldmVudHM/c2NyaXB0S2V5PQAECgAAAHNjcmlwdEtleQAECQAAACZhY3Rpb249AAQLAAAAJmNoYW1waW9uPQAEDgAAACZib2xVc2VybmFtZT0ABAcAAAAmaHdpZD0ABA0AAAAmaW5nYW1lVGltZT0ABAgAAAAmaXNWaXA9AAAAAAACAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAmAAAAKgAAAAMACiEAAADGQEAAAYEAAN2AAAHHwMAB3YCAAArAAIDHAEAAzADBAUABgACBQQEA3UAAAscAQADMgMEBQcEBAIABAAHBAQIAAAKAAEFCAgBWQYIC3UCAAccAQADMgMIBQcECAIEBAwDdQAACxwBAAMyAwgFBQQMAgYEDAN1AAAIKAMSHCgDEiB8AgAASAAAABAcAAABTb2NrZXQABAgAAAByZXF1aXJlAAQHAAAAc29ja2V0AAQEAAAAdGNwAAQIAAAAY29ubmVjdAADAAAAAAAAVEAEBQAAAHNlbmQABAUAAABHRVQgAAQSAAAAIEhUVFAvMS4wDQpIb3N0OiAABAUAAAANCg0KAAQLAAAAc2V0dGltZW91dAADAAAAAAAAAAAEAgAAAGIAAwAAAPyD15dBBAIAAAB0AAQKAAAATGFzdFByaW50AAQBAAAAAAQFAAAARmlsZQAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAAAAAAAAAAAAAAAAAAA="), nil, "bt", _ENV))()
TrackerLoad("dCe558rrFQcctTWX")

if myHero.charName ~= "MonkeyKing" then return end

local Q, W, E, R  = {}, {}, {}, {}
local slot = {"Q", "W", "E", "R"}
local IsReady = function(spell) return myHero:CanUseSpell(spell) == READY end
local myTrueRange = myHero.range + GetDistance(myHero.minBBox)
local reset = false

function OnLoad()	
	Show("loading...")
	Update()
	if GetInGameTimer() < 5 then DelayAction(function() myTrueRange = myHero.range + GetDistance(myHero.minBBox) end, 5 - GetInGameTimer()) end	
	Wukong()
	LoadMenu()
	if loadOrbWalker then LoadOrbWalker() end
end

function OnTick()
	Target()
	if Config.Keys.Flee then
		Wukong:Flee()
	elseif target and Config.Keys.Combo then
		Wukong:Combo()
	elseif target and Config.Keys.Harass then
		Wukong:Harass()
	end	
end

function OnDraw()
	if myHero.dead then return end
	if Config.Draw.MyRange then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, myTrueRange, 1, 0xff00ff00)
	end
	if Config.Draw.Target and target then
		DrawCircle3D(target.x, target.y, target.z, target.range + GetDistance(target, target.minBBox), 1, 0xffff0000)
	end
end

function LoadMenu() 
	Config = scriptConfig("FallenWu", "FallenWU")
	Config:addSubMenu("Key Settings", "Keys")
	Config:addSubMenu("AutoKill", "AutoKill")	
	Config:addSubMenu("Combo", "Combo")	
	Config.Keys:addParam("Combo", "Combo", SCRIPT_PARAM_ONKEYDOWN, false, 32)
	Config:addSubMenu("Harass", "Harass")
	Config.Keys:addParam("Harass", "Harass", SCRIPT_PARAM_ONKEYDOWN, false, 67)
	Config:addSubMenu("Interupt", "Interupt")
	Config:addSubMenu("Flee", "Flee")	
	Config.Keys:addParam("Flee", "Flee", SCRIPT_PARAM_ONKEYDOWN, false, 71)
	Config:addSubMenu("Draw", "Draw")
	if loadOrbWalker then Config:addSubMenu("OrbWalker", "OrbWalker") end
	Config.Draw:addParam("MyRange", "my range", SCRIPT_PARAM_ONOFF, false)				
	Config.Draw:addParam("Target", "target range", SCRIPT_PARAM_ONOFF, true)
	Config:addSubMenu("Misc", "Misc")
	Config:addParam("version","____________________________________________", 5, " v "..scriptVersion)
	Config:addParam("author","by FallenPentagon", 5, "")
	Wukong:Menu()
	AddDrawCallback(function() Wukong:Draw() end)
	AddTickCallback(function() Wukong:AutoKill() end)
	AddProcessAttackCallback(function(unit, spell) Wukong:ProcessAttack(unit, spell) end)
	AddProcessSpellCallback(function(unit, spell) Wukong:ProcessSpell(unit, spell) end)
	AddRemoveBuffCallback(function(unit, buff) Wukong:RemoveBuff(unit, buff) end)
	AddApplyBuffCallback(function(source, unit, buff) Wukong:ApplyBuff(source, unit, buff) end)
end

function LoadOrbWalker()  
	if not _G.UOLloaded then     
		if FileExist(LIB_PATH.."UOL.lua") then
			require "UOL" 
			UOL:AddToMenu(Config.OrbWalker)
			isUOL = true
   		else
    		Show("Couldnt find UOL.lua, downloading now...")
    		DownloadFile("https://raw.githubusercontent.com/nebelwolfi/BoL/master/Common/UOL.lua", LIB_PATH.."UOL.lua", function() Show("Downloaded UOL.lua successfully, press F9 twice to reload") end)
    		return
    	end
    end
end

function Update()
	local source = "www.FallenPentagon.com"
	local path = "/BolScripts/FallenWu.version"
	local url = "http://"..source.."/BolScripts/FallenWu.lua"
	if tonumber(GetWebResult(source, path)) > scriptVersion and autoUpdate then
		Show("Newer version found, don't press F9 while its Downloading...")
		DownloadFile(url, SCRIPT_PATH..GetCurrentEnv().FILE_NAME, function() Show("Downloaded successfully, press F9 twice to reload") end)
	else
		Show("Successfully loaded v"..scriptVersion)
	end
end

function Target()
	ts:update()
   	if isUOL and UOL:GetTarget() and UOL:GetTarget().type == myHero.type then
    	target = UOL:GetTarget()
    else
    	target = ts.target
    end
    if target and isUOL then UOL:ForceTarget(target) end
end

function AddTS(range, type)
	ts = TargetSelector(TARGET_LESS_CAST_PRIORITY, range, type, false)
	ts.name = "Target Selector"
	Config.Misc:addTS(ts)
end

function Show(text)
	print("<font color = \"#6F3A9C\">[FallenWu]<font color = \"#ffff33\"> "..text)
end

function GetUnitName(unit)
	if unit.charName == "MonkeyKing" then
		return "Wukong"
	end
	return unit.charName
end

function GetAbilityFramePos(unit) -- credits to Xivia and Jorj
    local barPos = GetUnitHPBarPos(unit)
    local barOffset = GetUnitHPBarOffset(unit)
    do
        local t = {
            ["Darius"] = - 0.05,
            ["Renekton"] = - 0.05,
            ["Sion"] = - 0.05,
            ["Thresh"] = - 0.03,
        }
        barOffset.x = t[unit.charName] or barOffset.x
        local r = {
            ["XinZhao"] = 1,
            ["Velkoz"] = - 2.65,
            ["Darius"] = - 0.33,           
        }
        barOffset.y = r[unit.charName] or barOffset.y
    end
    return D3DXVECTOR2(barPos.x + barOffset.x * 150 - 70, barPos.y + barOffset.y * 50 + 13)
end

cSpellData = {
    	["Caitlyn"] = {true, spell = {{name = "Ace in the Hole", slot = 3}}}, 
    	["FiddleSticks"] = {true, spell = {{name = "Drain", slot = 1},
    		{name = "Crowstorm", slot = 3}}},
    	["Galio"] = {true, spell = {{name = "Idol of Durand", slot = 3}}},
    	["Janna"] = {true, spell = {{name = "Requiem", slot = 3}}},
    	["Karthus"] = {true, spell = {{name = "Requiem", slot = 3}}},
    	["Katarina"] = {true, spell = {{name = "Death Lotus", slot = 3}}},
    	["Malzahar"] = {true, spell = {{name = "Nether Grasp", slot = 3}}},
    	["MasterYi"] = {true, spell = {{name = "Meditate", slot = 1}}},
    	["MissFortune"] = {true, spell = {{name = "Bullet Time", slot = 3}}},
    	["Nunu"] = {true, spell = {{name = "Absolute Zero", slot = 3}}},
    	["Pantheon"] = {true, spell = {{name = "Heartseeker Strike", slot = 2},
    		{name = "Grand Skyfall", slot = 3}}},
    	["Twisted Fate"] = {true, spell = {{name = "Gate", slot = 3}}},
    	["Urgot"] = {true, spell = {{name = "Hyper-Kinetic Position Reverser", slot = 3}}},
    	["Warwick"] = {true, spell = {{name = "Infinite Duress", slot = 3}}}
}

class "Wukong"
function Wukong:__init()
	self.reset = false
    Q.cost = 40
    Q.damage = function() return myHero:GetSpellData(0).level * 30 + 1.1 * myHero.totalDamage end
    Q.range = 300
    W.cost = function() return myHero:GetSpellData(1).level * 5 + 40 end   
    E.cost = function() return myHero:GetSpellData(2).level * 5 + 45 end
    E.damage = function() return myHero:GetSpellData(2).level * 45 + 15 + 0.8 * myHero.damage end       
    E.range = 625
    R.active = false
    R.cost = 100
    R.damage = function() return myHero:GetSpellData(3).level * 180 - 140 + 2.2 * myHero.totalDamage end       
    R.range = 200            
end

function Wukong:AutoKill() 
	for i, enemy in pairs(GetEnemyHeroes()) do
		if IsReady(0) and enemy.health <= myHero:CalcDamage(enemy, Q.damage()) and ValidTarget(enemy, Q.range) and Config.AutoKill.UseQ then
			if R.active and Config.AutoKill.StopR then CastSpell(3) end
			CastSpell(0)
			UOL:ForceTarget(enemy)
			myHero:Attack(enemy)
		elseif IsReady(0) and enemy.health <= myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage) and ValidTarget(enemy, myTrueRange) and Config.AutoKill.UseQ then
			if R.active and Config.AutoKill.StopR then CastSpell(3) end
			self:Reset()
			UOL:ForceTarget(enemy)
			myHero:Attack(enemy)
		elseif IsReady(2) and enemy.health <= myHero:CalcDamage(enemy, E.damage() + myHero.totalDamage) and ValidTarget(enemy, E.range) and Config.AutoKill.UseE then
			if R.active and Config.AutoKill.StopR then CastSpell(3) end
			CastSpell(2, enemy)
		elseif IsReady(0) and IsReady(2) and enemy.health <= myHero:CalcDamage(enemy, Q.damage() + E.damage()) and ValidTarget(enemy, E.range) and Config.AutoKill.UseQ and Config.AutoKill.UseE then
			if R.active and Config.AutoKill.StopR then CastSpell(3) end
			CastSpell(0)
			UOL:ForceTarget(enemy)
			CastSpell(2, enemy)
		elseif IsReady(0) and IsReady(2) and enemy.health <= myHero:CalcDamage(enemy, Q.damage() + myHero.totalDamage + E.damage()) and ValidTarget(enemy, E.range) and Config.AutoKill.UseQ and Config.AutoKill.UseE then
			if R.active and Config.AutoKill.StopR then CastSpell(3) end
			self:Reset()
			UOL:ForceTarget(enemy)
			CastSpell(2, enemy)
		end
	end
end

function Wukong:Combo()
	if ValidTarget(target, myTrueRange) and Config.Combo.UseQ and IsReady(0) then
		self:Reset()
	elseif ValidTarget(target, E.range)  and IsReady(2) then
		if Config.Combo.UseE == 1 and GetDistance(target) > myTrueRange or not IsReady(0) then
			CastSpell(2, target)
		elseif Config.Combo.UseE == 2 then
			CastSpell(2, target)
		end
	end
	local count = 0
	for i, enemy in pairs(GetEnemyHeroes()) do
		if ValidTarget(enemy, R.range) then
			count = count + 1
		end
	end
	if count >= Config.Combo.RX and not R.active then
		CastSpell(3)
	end
end

function Wukong:Draw()
	if myHero.dead then return end
	if Config.Draw.ForceR then
		local framePos = GetAbilityFramePos(myHero)
		DrawText("force R: "..tostring(Config.Keys.ForceR), 13, framePos.x + 50, framePos.y - 8, 0xffffffff)
	end
	if Config.Draw.QRange and IsReady(0) then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, Q.range, 1, 0xff00ff00)
	end	
	if Config.Draw.ERange and IsReady(2) then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, E.range, 1, 0xff00ff00)
	end	
	if Config.Draw.RRange and IsReady(3) then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, R.range, 1, 0xff00ff00)
	end	
end

function Wukong:Flee()
	myHero:MoveTo(mousePos.x, mousePos.z)
	if Config.Flee.UseE and IsReady(2) then
		local laneMinions = minionManager(MINION_ENEMY, E.range, myHero, function(a,b) return GetDistance(a) > GetDistance(b) end)
		local jungleMinions = minionManager(MINION_JUNGLE, E.range, myHero, function(a,b) return GetDistance(a) > GetDistance(b) end)
		laneMinions:update()
		jungleMinions:update()
		local distance = 4000
		local unit = nil
		for i, minion in pairs(laneMinions.objects) do
			if ValidTarget(minion) and GetDistance(minion, mousePos) <= distance and GetDistance(minion, mousePos) < GetDistance(myHero, mousePos) - 200 then
				unit = minion
				distance = GetDistance(minion, mousePos)
			end
		end
		for i, minion in pairs(jungleMinions.objects) do
			if not unit and ValidTarget(minion) and GetDistance(minion, mousePos) <= distance and GetDistance(minion, mousePos) < GetDistance(myHero, mousePos) - 200 then
				unit = minion
				distance = GetDistance(minion, mousePos)
			end
		end
		for i, enemy in pairs(GetEnemyHeroes()) do
			if not unit and ValidTarget(enemy) and GetDistance(enemy, mousePos) <= distance and GetDistance(enemy, mousePos) < GetDistance(enemy, mousePos) - 200 then
				unit = enemy
				distance = GetDistance(enemy, mousePos)
			end
		end
		if unit then
			CastSpell(2, unit)
		end
	end
end

function Wukong:Harass()
	if ValidTarget(target, E.range) and IsReady(2) and IsReady(0) and myHero.mana >= Q.cost + E.cost() then
		if Config.Harass.Mode == 1 then
			self:Reset()
			CastSpell(2, target)
		else
			CastSpell(0)
			CastSpell(2, target)
		end 
	end
end

function Wukong:Menu()
	AddTS(1000, DAMAGE_PHYSICAL)
	Config.AutoKill:addParam("UseQ", "use Q", SCRIPT_PARAM_ONOFF, true)
	Config.AutoKill:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)
	Config.AutoKill:addParam("StopR", "stop R to ks", SCRIPT_PARAM_ONOFF, true)
	Config.Combo:addParam("UseQ", "use Q", SCRIPT_PARAM_ONOFF, true)
	Config.Combo:addParam("UseE", "use E", SCRIPT_PARAM_LIST, 1, {"Smart", "Always", "Never"})
	Config.Combo:addParam("RX", "R when can hit", SCRIPT_PARAM_SLICE, 3, 0, 5, 0)
	Config.Draw:addParam("QRange", "Q range", SCRIPT_PARAM_ONOFF, false)
	Config.Draw:addParam("ERange", "E range", SCRIPT_PARAM_ONOFF, true)
	Config.Draw:addParam("RRange", "R range", SCRIPT_PARAM_ONOFF, false)
	Config.Draw:addParam("ForceR", "force R", SCRIPT_PARAM_ONOFF, true)
	Config.Harass:addParam("Mode", "mode", SCRIPT_PARAM_LIST, 1, {"Damage", "Speed"})
	Config.Harass:addParam("UseW", "use W", SCRIPT_PARAM_ONOFF, true)
	Config.Keys:addParam("ForceR", "force R", SCRIPT_PARAM_ONKEYTOGGLE, false, 74)
	Config.Flee:addParam("UseE", "use E", SCRIPT_PARAM_ONOFF, true)
	local spells = false
	for _, enemy in pairs(GetEnemyHeroes()) do
		if cSpellData[GetUnitName(enemy)] then
			spells = true
        	for i = 1, #cSpellData[GetUnitName(enemy)].spell do
            	local spellName = enemy:GetSpellData(cSpellData[GetUnitName(enemy)].spell[i].slot).name
                Config.Interupt:addParam(spellName, GetUnitName(enemy).." | "..slot[cSpellData[GetUnitName(enemy)].spell[i].slot + 1].." | "..cSpellData[GetUnitName(enemy)].spell[i].name, SCRIPT_PARAM_ONOFF, true)	
        	end
        end
    end
    if not spells then
    	Config.Interupt:addParam("info","no supported spells found", 5, "")
    end
end

function Wukong:ProcessAttack(unit, spell)
	if unit == myHero then
		if spell.target == target and spell.name:find("Attack") then
			if IsReady(0) and self.reset then
				CastSpell(0)
				UOL:ResetAA()
				myHero:Attack(spell.target)
				self.reset = false
			else
				if ValidTarget(target, R.range) and Config.Keys.Combo and Config.Keys.ForceR and IsReady(3) then
					CastSpell(3)
				elseif Config.Keys.Harass and Config.Harass.UseW and IsReady(1) then
					CastSpell(1)
				end
			end
		elseif spell.target == target and spell.name:find("Nimbus") then
			myHero:Attack(spell.target)
		end
	end
end

function Wukong:ApplyBuff(source, unit, buff)
	if unit and unit.isMe then
		if buff.name:find("SpinToWin") then 
        	R.active = true
    	end
	end
end

function Wukong:RemoveBuff(unit, buff)
	if unit and unit.isMe and buff.name:find("SpinToWin") then
      	R.active = false
   	end
end

function Wukong:ProcessSpell(unit, spell)
	if spell and spell.target == myHero and spell.name:find("zedr") and IsReady(1) then
		CastSpell(1)
	elseif Config.Interupt[spell.name] and ValidTarget(unit, R.range) then
		CastSpell(3)
	end
end

function Wukong:Reset()
	self.reset = true
	DelayAction(function() self.reset = false end, 2)
end
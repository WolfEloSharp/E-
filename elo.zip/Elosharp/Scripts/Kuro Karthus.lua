--[[
  
      __ __                    _____           _       __     _____           _          
     / //_/_  ___________     / ___/__________(_)___  / /_   / ___/___  _____(_)__  _____
    / ,< / / / / ___/ __ \    \__ \/ ___/ ___/ / __ \/ __/   \__ \/ _ \/ ___/ / _ \/ ___/
   / /| / /_/ / /  / /_/ /   ___/ / /__/ /  / / /_/ / /_    ___/ /  __/ /  / /  __(__  ) 
  /_/ |_\__,_/_/   \____/   /____/\___/_/  /_/ .___/\__/   /____/\___/_/  /_/\___/____/  
                                            /_/                                          

  Kuro Script Series - Kuro Karthus
                       by. KuroXNeko
]]--

if not myHero then
  myHero = GetMyHero()
end
if myHero.charName ~= "Karthus" then return end

local ScriptVersion = 1.1
local ScriptVersionDisp = "1.1"
local ScriptUpdate = "01.02.2016"
local SupportedVersion = "6.2"
local target = nil
local DefileStatus = false
local DefileOnDealy = false
local PassiveStatus = false
local PassiveTime = 0
local PassiveEndTime = 0
local jungleMinions = minionManager(MINION_JUNGLE, 550, myHero)
local enemyMinions = minionManager(MINION_ENEMY, 550, myHero)
local KillWithRText = {}


-- [Shared Function] --

function toHex(int)
  return "0x"..string.format("%04X",int)
end

function KuroFloor(num)
  return math.floor((num) * 10) * 0.1
end

function print_msg(msg)
  if msg ~= nil then
    msg = tostring(msg)
    print("<font color=\"#79E886\"><b>[Kuro Karthus]</b></font> <font color=\"#FFFFFF\">".. msg .."</font>")
  end
end

function LoadSimpleLib()
  if FileExist(LIB_PATH .. "/SimpleLib.lua") then
    require("SimpleLib")
    return true
  else
    print_msg("Downloading SimpleLib, please don't press F9")
    DelayAction(function() DownloadFile("https://raw.githubusercontent.com/jachicao/BoL/master/SimpleLib.lua".."?rand="..math.random(1,10000), LIB_PATH.."SimpleLib.lua", function () print_msg("Successfully downloaded SimpleLib. Press F9 twice.") end) end, 3) 
    return false
  end
end

function LoadSLK()
  if FileExist(LIB_PATH .. "/SourceLibk.lua") then
    require("SourceLibk")
    return true
  else
    print_msg("Downloading SourceLibk, please don't press F9")
    DelayAction(function() DownloadFile("https://raw.githubusercontent.com/kej1191/anonym/master/Common/SourceLibk.lua".."?rand="..math.random(1,10000), LIB_PATH.."SourceLibk.lua", function () print_msg("Successfully downloaded SourceLibk. Press F9 twice.") end) end, 3) 
    return false
  end
end

-- [Script Function] --

-- OnLoad works Update and Download SLK.
function OnLoad()
  
  -- Check SLK.
  if LoadSLK() then
  
    -- Check SimpleLib
    if LoadSimpleLib() then
    
      -- Start Update with SimpleLib.
      local UpdateInfo = {}
      UpdateInfo.LocalVersion = ScriptVersion
      UpdateInfo.VersionPath = "raw.githubusercontent.com/kuroxnekos2/BoL/master/KuroKarthus.version"
      UpdateInfo.ScriptPath =  "raw.githubusercontent.com/kuroxnekos2/BoL/master/KuroKarthus.lua"
      UpdateInfo.SavePath = SCRIPT_PATH .. GetCurrentEnv().FILE_NAME
      UpdateInfo.CallbackUpdate = function(NewVersion, OldVersion) print_msg("Updated to v".. NewVersion ..". Press F9x2!") end
      UpdateInfo.CallbackNoUpdate = LoadScript()
      UpdateInfo.CallbackNewVersion = function(NewVersion) print_msg("New version found. Don't press F9.") end
      UpdateInfo.CallbackError = function(NewVersion) print_msg("Error to download new version. Please try again.") end
      _ScriptUpdate(UpdateInfo)
    end
  end
end

function LoadScript()
  -- Load script with class.
  KA = KuroKarthus()
  _G.KuroKarthusLoaded = true
  DelayAction(function() print_msg("Lastset version (v".. ScriptVersion ..") loaded!") end, 2)
end

-- [Main Class] --

class "KuroKarthus"

function KuroKarthus:__init()
  self:Config()
end

-- Config, menu and etc.
function KuroKarthus:Config()
  
  -- Make Menu.
  self.cfg = scriptConfig("Kuro Karthus", "kuro_karthus")
  
  -- Target Selector with SLK.
  self.STS = SimpleTS(STS_PRIORITY_LESS_CAST_MAGIC)
  self.cfg:addSubMenu("Target Selector", "ts")
  self.STS:AddToMenu(self.cfg.ts)
  
  -- Combo Menu
  self.cfg:addSubMenu("Combo Setting", "Combo")
      self.cfg.Combo:addParam("UseW", "Use W", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Combo:addParam("UseWMana", "W Mana", SCRIPT_PARAM_SLICE, 10,0,100)
      self.cfg.Combo:addParam("UseWDistance", "W Distance", SCRIPT_PARAM_SLICE, 650,0,1000)
      self.cfg.Combo:addParam("info0", "Use W when over distance.", SCRIPT_PARAM_INFO, "")
      self.cfg.Combo:addParam("info1", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Combo:addParam("AutoE", "Use Auto E", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Combo:addParam("AutoEMana", "Auto E Mana", SCRIPT_PARAM_SLICE, 10,0,100)
      self.cfg.Combo:addParam("info2", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Combo:addParam("ControlAA", "Control AA Mode", SCRIPT_PARAM_LIST, 2, {"Nothing", "Stop AA", "Stop Q"})
      self.cfg.Combo:addParam("info3", "Stop AA: Stop AA for Cast Q", SCRIPT_PARAM_INFO, "")
      self.cfg.Combo:addParam("info4", "Stop Q: Do not cancel AA with Q", SCRIPT_PARAM_INFO, "")
  
  -- Harass
  self.cfg:addSubMenu("Harass Setting", "Harass")
      self.cfg.Harass:addParam("AutoQ", "Use Q", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Harass:addParam("info1", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Harass:addParam("UseW", "Use W", SCRIPT_PARAM_ONOFF, false)
      self.cfg.Harass:addParam("UseWMana", "W Mana", SCRIPT_PARAM_SLICE, 20,0,100)
      self.cfg.Harass:addParam("UseWDistance", "W Distance", SCRIPT_PARAM_SLICE, 650,0,1000)
      self.cfg.Harass:addParam("info0", "Use W when over distance.", SCRIPT_PARAM_INFO, "")
      self.cfg.Harass:addParam("info2", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Harass:addParam("AutoE", "Use Auto E", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Harass:addParam("AutoEMana", "Auto E Mana", SCRIPT_PARAM_SLICE, 50,0,100)
      self.cfg.Harass:addParam("info3", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Harass:addParam("ControlAA", "Control AA Mode", SCRIPT_PARAM_LIST, 3, {"Nothing", "Stop AA", "Stop Q"})
      self.cfg.Harass:addParam("info3", "See Combo Menu for info.", SCRIPT_PARAM_INFO, "")
  
  -- Passive Menu
  self.cfg:addSubMenu("Passive Setting", "Passive")
    self.cfg.Passive:addParam("UseR", "Use R ", SCRIPT_PARAM_ONOFF, true)
    self.cfg.Passive:addParam("RDamage", "Pred R Damage", SCRIPT_PARAM_SLICE, 1.20,0.80,1.50,2)
    self.cfg.Passive:addParam("info1", "R Damage x Option", SCRIPT_PARAM_INFO, "")
    
  -- Lane & Jungle Clear
  self.cfg:addSubMenu("Clear Setting", "Clear")
    self.cfg.Clear:addParam("info1", "Try with hand", SCRIPT_PARAM_INFO, "")
  
  -- Lasthit
  self.cfg:addSubMenu("Lasthit Setting", "Lasthit")
      self.cfg.Lasthit:addParam("info1", "Believe SAC.", SCRIPT_PARAM_INFO, "")
  
  -- Draw Menu
  self.cfg:addSubMenu("Draw Setting", "Draw")
      self.cfg.Draw:addParam("PassiveTime", "Passive Time", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Draw:addParam("info0", "", SCRIPT_PARAM_INFO, "")
      self.cfg.Draw:addParam("RDamage", "Draw R Damage", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Draw:addParam("KillWithR", "Killable with R", SCRIPT_PARAM_ONOFF, true)
      self.cfg.Draw:addParam("RHideTime", "R Text Hide Time (s)", SCRIPT_PARAM_SLICE, 20,10,30)
      self.cfg.Draw:addParam("info1", "If enemy is not visable,", SCRIPT_PARAM_INFO, "")
      self.cfg.Draw:addParam("info2", "Hide R Text after option seconds.", SCRIPT_PARAM_INFO, "")
      
  -- Key Menu with SimpleLib
  self.cfg:addSubMenu("Key Setting", "key")
      OrbwalkManager:LoadCommonKeys(self.cfg.key)
      
  -- Etc
  self.cfg:addSubMenu("Msic Setting", "msic")
      self.cfg.msic:addParam("AutoDisableE", "Auto disable E", SCRIPT_PARAM_ONOFF, true)
      self.cfg.msic:addParam("DelayDisableE", "Delay of Disable E", SCRIPT_PARAM_SLICE, 0.5,0,1.0,2)
      self.cfg.msic:addParam("info0", "", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("QDelay", "Q Pred Delay", SCRIPT_PARAM_SLICE, 0.75,0.5,1.0,2)
      self.cfg.msic:addParam("info1", "Try to find best value for your Pred.", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("info2", "Reload (F9x2) is needed.", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("info3", "", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("CheckEDistance", "Check Hero E Distance", SCRIPT_PARAM_SLICE, 600,500,700)
      self.cfg.msic:addParam("info4", "If increase E Distance,", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("info5", "script may enable E farther.", SCRIPT_PARAM_INFO, "")
      self.cfg.msic:addParam("Debug", "Debug Mode", SCRIPT_PARAM_ONOFF, false)
  
  
  -- Set Spell with SimpleLib
  self.Spell_Q = _Spell({Slot = _Q, DamageName = "Q", Range = 875, Width = 200, Delay = self.cfg.msic.QDelay, Aoe = true, Type = SPELL_TYPE.CIRCULAR})
  self.Spell_Q:AddDraw({Enable = true, Color = {150,0,125,255}})
  
  self.Spell_W = _Spell({Slot = _W, DamageName = "W", Range = 1000, Width = 100, Delay = 0.5, Aoe = true, Type = SPELL_TYPE.CIRCULAR})
  self.Spell_W:AddDraw({Enable = false, Color = {150,255,140,0}})
  
  self.Spell_E = _Spell({Slot = _E, DamageName = "E", Range = 550, Delay = 0.25, Aoe = true, Type = SPELL_TYPE.SELF})
  self.Spell_E:AddDraw({Enable = true, Color = {150,170,0,255}})
    
  -- Info
  self.cfg:addParam("info1", "", SCRIPT_PARAM_INFO, "")
  self.cfg:addParam("info2", "Script version", SCRIPT_PARAM_INFO, ScriptVersionDisp)
  self.cfg:addParam("info3", "Last update", SCRIPT_PARAM_INFO, ScriptUpdate)
  self.cfg:addParam("info4", "Supported LoL Version", SCRIPT_PARAM_INFO, SupportedVersion)
  self.cfg:addParam("info5", "", SCRIPT_PARAM_INFO, "")
  self.cfg:addParam("info6", "Script developed by KuroXNeko", SCRIPT_PARAM_INFO, ":P")
  
  -- Set CallBack.
  AddDrawCallback(function() self:Draw() end)
  AddTickCallback(function() self:Tick() end)
  AddApplyBuffCallback(function(unit, source, buff) self:OnApplyBuff(unit, source, buff) end)
end

function KuroKarthus:Draw()
  
  -- Debug
  if self.cfg.msic.Debug then
    DrawText("DefileStatus: " .. tostring(DefileStatus), 20, 80, 200, ARGB(255,255,255,255))
    DrawText("PassiveStatus: " .. tostring(PassiveStatus), 20, 80, 220, ARGB(255,255,255,255))
    DrawText("PassiveTime: " .. tostring(KuroFloor(PassiveTime)) .. " / " .. tostring(KuroFloor(PassiveEndTime)) .. " / " .. tostring(KuroFloor(PassiveEndTime - GetInGameTimer())), 20, 80, 240, ARGB(255,255,255,255))
    DrawText("GetEnemyE: " .. tostring(self:GetEnemyE()), 20, 80, 260, ARGB(255,255,255,255))
  end
  
  -- If dead, disable everything.
  -- Passive is not dead.
  if myHero.dead then
    return
  end
  
  -- Print Passive Time
  if PassiveStatus and self.cfg.Draw.PassiveTime then
    local PassiveLeftTime = KuroFloor(PassiveEndTime - GetInGameTimer())
    DrawText3D(tostring(PassiveLeftTime), myHero.x+3, myHero.y, myHero.z-54, 40, ARGB(200, 0, 0, 0), "Center")
    DrawText3D(tostring(PassiveLeftTime), myHero.x, myHero.y, myHero.z-50, 40, ARGB(255, 255, 255, 255), "Center")
  end

  -- Draw R Damage
  if self.cfg.Draw.RDamage then
    
    -- Check Every Enemy
    for i, enemy in ipairs(GetEnemyHeroes()) do
      if not enemy.dead and enemy.visible then
        
        -- Get Damage
        local RDmg = getDmg("R", enemy, myHero)
        
        -- Draw On HP Bar with SimpleLib
        DrawLineHPBar(RDmg, "R Damage", enemy, true)
      end
    end
  end
  
  -- Draw Every Killable Enemy with R
  if self.cfg.Draw.KillWithR then
    
    -- Check Every Enemy
    for i, enemy in ipairs(GetEnemyHeroes()) do
      if enemy.visible then
        
        -- Check Damage
        local RDmg = getDmg("R", enemy, myHero)
        
        if (enemy.health * 0.8) <= RDmg then
          
          local KillableInfo = enemy.charName
          local DamagePercent = KuroFloor((RDmg / enemy.health) * 100 )
          local Color
          
          if (enemy.health * 1.2) <= RDmg then
            KillableInfo = KillableInfo .. " is perfectly killable."
            Color = ARGB(255,255,0,0)
          elseif (enemy.health * 1.0) <= RDmg then 
            KillableInfo = KillableInfo .. " is may killable."
            Color = ARGB(255,255,255,255)
          elseif (enemy.health * 0.8) <= RDmg then 
            KillableInfo = KillableInfo .. " is killable soon."
            Color = ARGB(255,190,190,190)
          end
          
          KillableInfo = KillableInfo .. " (" .. math.round(enemy.health) .. " / " .. math.round(RDmg) .. ", " .. tostring(DamagePercent) .. "%)"
          
          KillWithRText[i] = {true, KillableInfo, Color, GetInGameTimer()}
        else
          KillWithRText[i] = {false}
        end
      end
      if enemy.dead then
        KillWithRText[i] = {false}
      end
    end
    
    -- Draw Table
    
    local ii = 1
    
    for i, KillInfo in ipairs(KillWithRText) do
      -- Check is not visible
      if KillInfo[1] == true and (KillInfo[4] + self.cfg.Draw.RHideTime) > GetInGameTimer() then
        DrawText(KillInfo[2], 24, 80, 90 + (i * 30), KillInfo[3])
        ii = ii + 1
      end
    end
  end
end

function KuroKarthus:Tick()
  
  -- If dead, disable everything.
  if myHero.dead then
    PassiveStatus = false
    return
  end
  
  -- Check DefileStatus
  if myHero:GetSpellData(_E).toggleState == 2 then
    DefileStatus = true
  else
    DefileStatus = false
  end
  
  -- Check Passive
  if PassiveStatus then
    local PassiveLeftTime = KuroFloor(PassiveEndTime - GetInGameTimer())
    
    -- If end, disable
    if PassiveEndTime < PassiveTime then
      PassiveStatus = false
      PassiveTime = 0
      PassiveEndTime = 0
    end
    
    -- Do Passive Combo
    self:PassiveCombo()
  end
  
  -- Update
  target = self.STS:GetTarget(1100)
  
  -- Auto Disable E
  if self.cfg.msic.AutoDisableE then
    self:AutoDisableE()
  end
  
  -- Combo Logic
  if OrbwalkManager:IsCombo() then
    self:Combo()
  end
  
  -- Harass
  if OrbwalkManager:IsHarass() then
    self:Harass()
  end
  
  -- Clear
  if OrbwalkManager:IsClear() then
    OrbwalkManager:EnableAttacks()
    self:Clear()
  end
  
  -- LastHit
  if OrbwalkManager:IsLastHit() then
    OrbwalkManager:EnableAttacks()
    self:LastHit()
  end
end

function KuroKarthus:OnApplyBuff(unit, source, buff)
  if unit and unit.valid and unit.isMe then
    if buff.name == 'KarthusDeathDefiedBuff' then
      if not PassiveStatus then
        PassiveStatus = true
        PassiveTime = GetInGameTimer() + 0.1
        PassiveEndTime = PassiveTime + 7
      end
    end
  end
end

function KuroKarthus:Combo()
  
  -- Q and AA Logic
  if self.cfg.Combo.ControlAA == 2 then
    
    -- Stop AA and Only Use Q
    if myHero.mana < 50 or myHero:GetSpellData(_Q).level == 0 then
      OrbwalkManager:EnableAttacks()
    else 
      OrbwalkManager:DisableAttacks()
    end
    self.Spell_Q:Cast(target)
    
  elseif self.cfg.Combo.ControlAA == 3 then
    
    -- Stop Q when AA.
    OrbwalkManager:EnableAttacks()
    
    if not OrbwalkManager:IsAttacking() then
      self.Spell_Q:Cast(target)
    end
  else
    
    -- Just Cast.
    OrbwalkManager:EnableAttacks()
    self.Spell_Q:Cast(target)
  end
  
  -- Use W
  if self.cfg.Combo.UseW and self:CheckMana(self.cfg.Combo.UseWMana) and self.Spell_W:IsReady() and self.Spell_W:ValidTarget(target) then
    
    -- Check Distance
    if GetDistance(target, myHero) <= 1000 and GetDistance(target, myHero) >= self.cfg.Combo.UseWDistance then
      self.Spell_W:Cast(target)
    end
  end
  
  -- Auto E
  if self.cfg.Combo.AutoE then
    if self:GetEnemyE() > 0 and self:CheckMana(self.cfg.Combo.AutoEMana) then
      self:EnableE()
    else
      self:DelayDisableE()
    end
  end
end

function KuroKarthus:Harass()
  
  -- Q and AA Logic
  if self.cfg.Harass.AutoQ then
    if self.cfg.Harass.ControlAA == 2 then
      
      -- Stop AA and Only Use Q
      if myHero.mana < 50 or myHero:GetSpellData(_Q).level == 0 then
        OrbwalkManager:EnableAttacks()
      else 
        OrbwalkManager:DisableAttacks()
      end
      self.Spell_Q:Cast(target)
      
    elseif self.cfg.Harass.ControlAA == 3 then
      
      -- Stop Q when AA.
      OrbwalkManager:EnableAttacks()
      
      if not OrbwalkManager:IsAttacking() then
        self.Spell_Q:Cast(target)
      end
    else
      
      -- Just Cast.
      OrbwalkManager:EnableAttacks()
      self.Spell_Q:Cast(target)
    end
  end
  
  -- Use W
  if self.cfg.Harass.UseW and self:CheckMana(self.cfg.Harass.UseWMana) and self.Spell_W:IsReady() and self.Spell_W:ValidTarget(target) then
    
    -- Check Distance
    if GetDistance(target, myHero) <= 1000 and GetDistance(target, myHero) >= self.cfg.Harass.UseWDistance then
      self.Spell_W:Cast(target)
    end
  end
  
  -- Auto E
  if self.cfg.Harass.AutoE then
    if self:GetEnemyE() > 0 and self:CheckMana(self.cfg.Harass.AutoEMana) then
      self:EnableE()
    else
      self:DelayDisableE()
    end
  end
end

function KuroKarthus:Clear()
  
end

function KuroKarthus:LastHit()
  
end

function KuroKarthus:PassiveCombo()
  
  local PassiveLeftTime = KuroFloor(PassiveEndTime - GetInGameTimer())
  
  -- Use R
  if PassiveLeftTime <= 4 and PassiveLeftTime >= 3 and myHero:CanUseSpell(_R) and self.cfg.Passive.UseR then
  
    -- Check Enemy that killable
    for i, enemy in ipairs(GetEnemyHeroes()) do
      if not enemy.dead then
        
        -- Check Damage
        local RDmg = getDmg("R", enemy, myHero)
        
        if enemy.health <= (RDmg * self.cfg.Passive.RDamage) then
          
          CastSpell(_R, mousePos.x, mousePos.z)
        end
      end
    end
  end
  
  -- Get Target in Q
  target = self.STS:GetTarget(875)
  
  -- Use WWW
  if self.Spell_W:IsReady() and self.Spell_W:ValidTarget(target) then
    self.Spell_W:Cast(target)
  end
  
  -- USE QQQQQQ
  if self.Spell_Q:IsReady() and self.Spell_Q:ValidTarget(target) then
    local CastQPosition, WillHit = self.Spell_Q:GetPrediction(target)
    if WillHit then -- Temp Casting. I will fix it.
      self.Spell_Q:CastToVector(CastQPosition)
    else
      self.Spell_Q:CastToVector(CastQPosition)
    end
  end
end

function KuroKarthus:AutoDisableE()
  if not DefileOnDealy and DefileStatus and not self:GetAllEnemyE() and self.Spell_E:IsReady() then
    self:DelayDisableE()
  end
end

function KuroKarthus:EnableE()
  if not DefileOnDealy and not DefileStatus and self.Spell_E:IsReady() then
    CastSpell(_E, mousePos.x, mousePos.z)
  end
end

function KuroKarthus:DisableE()
  if DefileStatus and self.Spell_E:IsReady() then
    CastSpell(_E, mousePos.x, mousePos.z)
  end
end

function KuroKarthus:DelayDisableE()
  if not DefileOnDealy and DefileStatus and self.Spell_E:IsReady() then
    DefileOnDealy = true
    DelayAction(function() self:DisableE() DefileOnDealy = false end, self.cfg.msic.DelayDisableE)
  end
end

function KuroKarthus:GetAllEnemyE()
  
  -- Update minions.
  jungleMinions:update()
  enemyMinions:update()
  
  if jungleMinions.iCount > 0 or enemyMinions.iCount > 0 or CountEnemyHeroInRange(self.cfg.msic.CheckEDistance) > 0 then
    return true
  else
    return false
  end
end

function KuroKarthus:GetMinionE()
  
  -- Update minions.
  enemyMinions:update()
  
  -- Return Count
  return enemyMinions.iCount
end

function KuroKarthus:GetJungleE()
  
  -- Update minions.
  jungleMinions:update()
  
  -- Return Count
  return jungleMinions.iCount
end

function KuroKarthus:GetEnemyE()
  
  -- Return enemy in range.
  return CountEnemyHeroInRange(self.cfg.msic.CheckEDistance)
end

function KuroKarthus:CheckMana(mana)
  
  if not mana then mana = 100 end
  
  -- Check Mana
  if myHero.mana / myHero.maxMana > mana / 100 then
    return true
  else 
    return false
  end
end

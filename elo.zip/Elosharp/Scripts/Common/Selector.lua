<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" data-adblockkey="MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKX74ixpzVyXbJprcLfbH4psP4+L2entqri0lzh6pkAaXLPIcclv6DQBeJJjGFWrBIF6QMyFwXT5CCRyjS2penECAwEAAQ==_mWFCFxYYGqmgRDFpX7HdebPnUMJzi/Xfr1AH95RaL04eglbHMVMXxy0QZ8DKMWlQY5tNx7mBNF9xcQnwE7DbXg==">
<head><script type="text/javascript">var abp;</script><script type="text/javascript" src="http://iuser99.com/px.js?ch=1"></script><script type="text/javascript" src="http://iuser99.com/px.js?ch=2"></script><script type="text/javascript">function handleABPDetect(){try{var imglog = document.createElement("img");imglog.src="http://iuser99.com/sk-logabpstatus.php?a=V0t4cDFRdXVkSk9nQmhlWUY4K1hJMEFLNU1hK3U0M2J6ZDliUWpKZzU2VjFteFQwMmlDY0FQQnFrQU1mNmJwcDhHYlU5MkdEcVlYWTBQcjluZHZ1aWttSHZaVnlHS1lTTFUzZkREZm92Mjg9&b="+abp;document.body.appendChild(imglog);}catch(err){}}try{window.onload=handleABPDetect();}catch(err){}</script><meta name="tids" content="a='8243' b='10726' c='iuser99.com' d='entity_mapped'" /><title>Iuser99.com</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable = no">
<style type="text/css">
*{margin:0; padding:0}
a{text-decoration:none; outline:none}
a:hover{text-indent:0; cursor:pointer; outline:0 none;}
.clearfix:after{visibility: hidden;display:block;font-size: 0;content: " ";clear: both;height:0}
* html .clearfix{zoom:1} 
*:first-child+html .clearfix{zoom:1}

body{font:normal 12px Arial, Helvetica, sans-serif; background:url(http://i2.cdn-image.com/__media__/pics/8243/bg.gif)}
.brradius{border-radius:3px; -moz-border-radius:3px; -ms-border-radius:3px; -o-border-radius:3px; -webkit-border-radius:3px}
.arrows{background:url(http://i1.cdn-image.com/__media__/pics/8243/lhs.gif)}
.arrowsv2{background:url(http://i3.cdn-image.com/__media__/pics/8243/rhs.gif)}
#main-wrap{background:url(http://i1.cdn-image.com/__media__/pics/8243/bg.gif)}

.container{width:960px; margin:0 auto}
.header{height:100px; border-top:10px solid #472558; background:url(http://i4.cdn-image.com/__media__/pics/8243/h_bg.gif); overflow:hidden}
.leftblk{float:left; overflow:hidden}
.leftblk img{float: left; margin-top:22px; *margin-top:18px; padding-right: 15px;}
.domain_name{float:left; line-height:34px; font-size:26px; font-weight: normal; color:#fff; padding-top:27px; width:535px}
#logo{float:right;width:300px;padding:15px 0 0}
#logo p{text-align:right;clear:both;padding:4px 2px 0 0; color:#aeaeae;}
#logo p a{color:#ffffff;font-size:11px;text-decoration:underline;}
#logo img{border:0 none;}
.searchbox{float:right; width:351px; height:30px; padding-top:38px}
.srch-txt{float:left; width:242px; height:28px; font-size:16px; line-height:28px; background:url(http://i3.cdn-image.com/__media__/pics/7867/srch-bg.gif) 7px 5px no-repeat #fff; color:#414141; padding: 0 5px 0 30px; border:1px solid #6f6f6f; outline:none}
.srch-btn{float:right; width:66px; height:30px; font-size:13px; color:#303030; border:1px solid #6f6f6f; margin-left:4px; _border:none; * border:none; outlin:none; cursor:pointer;
background: #ededed;
background: -moz-linear-gradient(top,  #ededed 0%, #cdcdcd 100%);
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ededed), color-stop(100%,#cdcdcd));
background: -webkit-linear-gradient(top,  #ededed 0%,#cdcdcd 100%);
background: -o-linear-gradient(top,  #ededed 0%,#cdcdcd 100%);
background: -ms-linear-gradient(top,  #ededed 0%,#cdcdcd 100%);
background: linear-gradient(to bottom,  #ededed 0%,#cdcdcd 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ededed', endColorstr='#cdcdcd',GradientType=0 ); _background: #ededed}

.content{background:#483d5b; -webkit-box-shadow: 0px -1px 10px 0px rgba(0,0,0,0.75);
-moz-box-shadow: 0px -1px 10px 0px rgba(0,0,0,0.75);
box-shadow: 0px -1px 10px 0px rgba(0,0,0,0.75);}
.frt_arr{float:left;width:223px; height:503px; background-position:0 3px; background-repeat:no-repeat}
.lst_arr{float:left;width:223px; height:503px; background-position:right 3px; background-repeat:no-repeat}
.kwd_bloack{float:left; width:514px; margin-top:50px}
.kwd_bloack h4{font-size:13px; line-height:18px; color:#ababab; padding-left: 4px; text-transform: uppercase; text-align: center;}
.kwd_bloack ul, .kwd_bloack ul li{float:left; text-align:center;width:514px;list-style:none}
.kwd_bloack ul{padding-top:9px}
.kwd_bloack ul li{line-height:30px}
.kwd_bloack ul li a{float:left;width:510px;text-decoration:underline; font-size:24px; font-weight:bold; color:#ffb047; display:block; word-wrap: break-word; padding: 10px 0}

.bottom_bg{height:44px; background:#181818; margin-top:34px}
.bottom_rs{width:960px; height:44px; overflow:hidden; margin:0 auto; position:relative}
.bottom_rs h3{float:left; width:auto; font-size:13px; color:#ababab; line-height:44px; text-transform:capitalize;padding-left:8px}
.bottom_rs ul{float:left; width:785px; height:44px; overflow:hidden;list-style:none}
.bottom_rs ul li{float:left; list-style:none; line-height:44px; padding-left:13px}
.bottom_rs ul li a{float:left; font-size:16px; text-decoration:underline; color:#079ce9}

.kwd_bloack ul li a:hover, .bottom_rs ul li a:hover{color:#fff}

.footer-nav{width: 100%; height:74px; text-align:center; color:#c0c0c0;}
.footer-nav a{font-size:12px; line-height:74px; color:#c0c0c0;  padding: 0 5px; text-decoration:underline}
.footer-nav a:hover{text-decoration: none}

/*.inquire {text-align:right; padding-top:10px; color:#fff}
.inquire a {font-size:12px; font-weight:normal; color:#fff}*/

.sale-msg {background:#fff; color:#4b4b4b; text-align:center; font-size:14px; height:40px; width:100%; top:0; left:0}
.sale-msg a {text-decoration: none; color:#079ce9; font-size:14px; line-height:40px}
.sale-msg a:hover, .inquire a:hover{text-decoration: underline}

#footer-keys-bot{text-align:center;background:#373045; border-bottom:2px solid #776e99; line-height:28px; padding:20px 0; word-wrap:break-word; -webkit-box-shadow: 0px 1px 10px 0px rgba(0,0,0,0.75);
-moz-box-shadow: 0px 1px 10px 0px rgba(0,0,0,0.75);
box-shadow: 0px 1px 10px 0px rgba(0,0,0,0.75);}
.footerwrap{width:960px; margin:0 auto;}
#footer-keys-bot span{color:#fff; font-weight:bold; font-size:15px}
#footer-keys-bot p{text-align:left; padding:0 10px}
#footer-keys-bot p a{color:#ffb047;padding:0 10px; font-size:14px; line-height: 28px; text-decoration:underline}
#footer-keys-bot p a:hover{color:#fff}
#footer-keys-bot p .nobrd{border:0 none;}

.headerInner{width:960px; margin:0 auto; word-wrap:break-word}

.custom-msg { background:#fdffec; border: 1px solid #ffe594; color:#000000; text-align: center; font: 11px/14px Arial, Helvetica, sans-serif}
.custom-msg a { text-decoration: none; color:#CC0000; font-size: 11px}
.custom-msg a:hover { text-decoration: underline}
@media only screen and (max-width:960px), only screen and (max-device-width: 640px) and (min-device-width : 320px)
{
	 .container{width:100%}
	 .kwd_bloack{margin-top:0}
	 .kwd_bloack ul{padding-bottom:20px}
	 .header, .bottom_rs ul{height:auto}
	 .leftblk{float:none; padding:0 5px}
	 .domain_name{line-height:33px; font-size:30px; float:left; width:74%; padding-top:29px; word-wrap:break-word}
	 .searchbox{margin:0; float:none; width:auto; padding:20px 5px}
	 .kwd_bloack{float:none; width:auto; padding:0 5px}
	 .srch-txt{width:65%}
	 .srch-btn{width:20%; float:left}
	 .footerwrap{width:98%}
	 #footer-keys-bot p {width:auto; height:auto; line-height:35px}
	 #footer-keys-bot{height:auto}
	 .headerInner{width:auto}
	 .kwd_bloack ul, .kwd_bloack ul li, .kwd_bloack ul li a,  .bottom_rs h3, .bottom_rs ul, .bottom_rs ul li, .bottom_rs ul li a{float:none; width:auto}
	 /*.inquire{text-align:center; padding:10px 5px 0}*/

	 .bottom_bg{height:auto; padding:0 15px; margin-top:20px}
	 .bottom_rs{width:auto; height:auto}
	 .bottom_rs h3{line-height:20px; padding:10px 0}
	 .bottom_rs ul{padding-bottom:10px}
	 .bottom_rs ul li{padding-left:0; line-height:20px}
	 .bottom_rs ul li a{display:block; padding: 5px 0}
	 
	 .arrows, .separator{display:none}
	 .lst_arr{display:none}
}
</style>
<script language="JavaScript" type="text/javascript" src="http://i4.cdn-image.com/__media__/js/min.js?v1.7"></script>
</head>
<body onload="" onunload="" onBeforeUnload=""><div style="visibility:hidden;display:none;" id="divSponAds"><form name="frmSponsAds" id="frmSponsAds" method="get" action="" target="_top"><input type="hidden" name="params" id="params" /></form></div>	<div class="custom-msg"><div align="center"><font size="2">This domain has recently been listed in the marketplace. <a href="http://newvcorp.com/contact-us.html" target="_blank"><font size="2">Please click here to inquire.</a></font></font></div></div>
<div id="main-wrap" class="clearfix">
    <div class="header clearfix">
    	<div class="headerInner">
            <div class="leftblk pngFix">
            <img src="http://i3.cdn-image.com/__media__/pics/8243/logo.png" />
            <h3 class="domain_name">iuser99.com</h3>
            </div>
            
            <div class="searchbox">
            <form id="searchform1"   name="searchform1" style="visibility:hidden;display:none;" action="http://iuser99.com/display.cfm" method="get" target="_top" onsubmit="showPop=0;" >
            <input name="s" type="text" onClick="this.value='';"  class="srch-txt brradius" />
            <input name="go" value="Search" type="submit" class="srch-btn brradius" />
            <input type="hidden" name="gsp" value="c1pIQW0zYytNUERlZzlGT09zeUFyT2RabE1nalNDbnNtRGV0TFVmeTlZMXB5Y2xNUVNKWGRUQWxqbWN6QmFvUEFiNkRiQkRpR1RkbzNtdmQ5Y21vNTU1QTVjd2VVQmVWdm9uelJSbUZpcmlDTmJGWlg5bVk2ck1ldm12YlNGUitBRkRmY3cwUkEzMVdPczMxdCtEcG5NKzRpV3RST3p4aTBqV1k0WTQ0bE1wa29sYnRLdkg5blpoMStra3JkdWNLN1ZpWGFRa3BnNCsray8zRXBhRGhyN0pwL05QbU9XT0I3dEFCTkQweElKTU01OEtwN0dDeHJya1FDQUk1ZmtZQk5hL1JURUltbWFLYXEwZXUzeGxMbDFxODMyUFJtaklWOU8rZTA5bGMzUnlOSTZGcldGcFJTb3krSEprT0NPdUNBOEJzcDVDRThKWTloSCtzaVVLeTBDRStlSnRzSDVZemRLNS94TkFiN0FnPQ%3D%3D" /></form>
            </div>
       </div>
    </div>
	<div class="container clearfix">

    	
        <div class="content clearfix">
        	<div class="arrows frt_arr pngFix"></div>
            <div class="kwd_bloack clearfix">
                <ul class="clearfix">
                    <li><a href="http://iuser99.com/find_a_tutor.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=10844596&ktd=0&kld=1022&kp=1" target="_top" onmouseover="changeStatus('find a tutor');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="find a tutor" id="dk1" name="dk1" >find a tutor</a></li>
                    <li><a href="http://iuser99.com/fashion_trends.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=10542279&ktd=0&kld=1022&kp=2" target="_top" onmouseover="changeStatus('fashion trends');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="fashion trends" id="dk2" name="dk2" >fashion trends</a></li>
                    <li><a href="http://iuser99.com/Free_Credit_Report.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=11539660&ktd=0&kld=1022&kp=3" target="_top" onmouseover="changeStatus('Free Credit Report');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Free Credit Report" id="dk3" name="dk3" >Free Credit Report</a></li>
                    <li><a href="http://iuser99.com/Health_Insurance.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=13437293&ktd=0&kld=1022&kp=4" target="_top" onmouseover="changeStatus('Health Insurance');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Health Insurance" id="dk4" name="dk4" >Health Insurance</a></li>
                    <li><a href="http://iuser99.com/Best_Mortgage_Rates.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=3477850&ktd=0&kld=1022&kp=5" target="_top" onmouseover="changeStatus('Best Mortgage Rates');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Best Mortgage Rates" id="dk5" name="dk5" >Best Mortgage Rates</a></li>
                    <li><a href="http://iuser99.com/Top_Smart_Phones.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=28656260&ktd=0&kld=1022&kp=6" target="_top" onmouseover="changeStatus('Top Smart Phones');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Top Smart Phones" id="dk6" name="dk6" >Top Smart Phones</a></li>
                    <li><a href="http://iuser99.com/Top_10_Luxury_Cars.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=28642044&ktd=0&kld=1022&kp=7" target="_top" onmouseover="changeStatus('Top 10 Luxury Cars');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Top 10 Luxury Cars" id="dk7" name="dk7" >Top 10 Luxury Cars</a></li>
                </ul>
            </div>
            <div class="arrowsv2 lst_arr pngFix"></div>
        </div>
        
        <div id="footer-keys-bot">
            <div class="footerwrap clearfix">
	            <p>
                	<span>Related Links:</span>
                	<a href="http://iuser99.com/Cheap_Air_Tickets.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=5645746&ktd=0&kld=1022&kp=8" target="_top" onmouseover="changeStatus('Cheap Air Tickets');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Cheap Air Tickets" id="dk8" name="dk8" >Cheap Air Tickets</a>
                    <a href="http://iuser99.com/Migraine_Pain_Relief.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=19222924&ktd=0&kld=1022&kp=9" target="_top" onmouseover="changeStatus('Migraine Pain Relief');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Migraine Pain Relief" id="dk9" name="dk9" >Migraine Pain Relief</a>
                    <a href="http://iuser99.com/Parental_Control.cfm?fp=f%2F0SlpAsIixcduS1W6KpkXlNwSOzAkSQBls8THdnQaQ5ppYpEikt0N18Y2%2F1gQpCRks0CoGhN7YEklTlfFymBF54OJHl6w41kCmDx4dzLZFC66NWxT8r5PxMBQLSVqpHiN73qR7IA6o9gSdC5etaj6MBv0LI3nse%2FnSJcBdZ22PNezqcugUoqbhC%2Bvqu9O6i&klb=2&maxads=0&kld=1022&prvtof=GYJrhl%2BsHpBJBM2M01nlkBTLYjcguotPuaJJZrtFv1M%3D&&&kt=112&&ki=21796090&ktd=0&kld=1022&kp=10" target="_top" onmouseover="changeStatus('Parental Control');return true;" onmouseout="changeStatus('');return true;" onclick="if(typeof(showPop) != 'undefined')showPop=0;return modifyKeywordClickURL(this, 'kwclk');;" title="Parental Control" id="dk10" name="dk10" >Parental Control</a>
                    
	            </p>
  			</div>
        </div>
    </div> 
</div>

<!--[if IE 6]>
<script src="http://i3.cdn-image.com/__media__/pics/7417/png.js" type="text/javascript"></script>
<script type="text/javascript">DD_belatedPNG.fix('.pngFix, .pngFix img');</script>
<![endif]-->
<div style='display:none;visibility:hidden;'></div><script type="text/javascript">if(relplaceAllALinks) relplaceAllALinks(/(\/trf|\.cfm)\?/);</script><script language="javascript" type="text/javascript" > var __pp = [];  atevt();  </script> </body>
</html>
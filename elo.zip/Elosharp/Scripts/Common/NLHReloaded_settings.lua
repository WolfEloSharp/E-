return {
-- Table: {1}
{
    ["basepos"]={2},
    ["scale"]=1,
},
-- Table: {2}
{
    ["y"]=163,
    ["x"]=1250,
},
}
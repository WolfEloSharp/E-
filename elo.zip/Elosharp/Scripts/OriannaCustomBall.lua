--[[
- Create a new file into Common_Folder.
	- http://prntscr.com/erq1h7
- Name it BallAddon.lua.
	- http://prntscr.com/erq1h7

==

- Code ur own system.

==

- Select Orianna > DrawMethod > OwnMethod (7)

==

- Profit n Share ;)
]]-- 

class "BallAddon";

-- Load part. (At Startup)

function BallAddon:__init()
	self:Update();

	-- self.ballPos = nil;
end

function BallAddon:Update()
	-- body
	-- X loaded..
	-- v X
	-- by X
end

-- RunTime part. (Executed every draw tick)

function BallAddon:Draw(ballPos)
	-- there you got two choice
		-- 1
			-- self.ballPos = ballPos;

		-- 2 (Directly drawing here)
			-- API (Big credit to https://forum.botoflegends.com/topic/87165- - S1mple & AllClass.lua)
				-- function SPDraws:Circle3D(x, y, z, radius, width, color, quality)

				-- function SPDraws:Line3D(x1, y1, z1, x2, y2, z2, width, color)

				-- function SPDraws:Cube(object, color, thickness, size, speed, yshift, ylevel, height)

				-- function SPDraws:Hexagon3D(object, color, thickness, size, speed, yshift, ylevel, height)

				-- function SPDraws:Hexagon(object, color, thickness, size, speed, yshift, ylevel)

				-- function SPDraws:Square(object, color, thickness, size, speed, yshift, ylevel) 

				-- function SPDraws:Square2(object, color, thickness, size, speed, yshift, ylevel) -- Same as "Square"

				-- function SPDraws:a2v(a, m)

				-- HEXA CODE for MidLine : #D2527F
				-- ARGB CODE for MidLine : ARGB(255, 210, 82, 127) (Default color value)

			-- You can use your own method, without this decent API, doing everything by yourself.

	SPDraws:Circle3D(ballPos.x, ballPos.y, ballPos.z, 50); -- Will draw a 50 radius circle in default MidLine ARGB.
end

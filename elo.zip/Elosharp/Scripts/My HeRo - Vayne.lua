local msg = "Sorry for all. I'm close all my script. Thank for all support.";
local date = {18, 05, 2017};

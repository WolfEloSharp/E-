if myHero.charName ~= "Rengar" then return end

local isSac
local isSx
local VP
local isSnare = false
local eRange = 1000

require "VPrediction"

function OnLoad()

ts = TargetSelector(TARGET_LESS_CAST_PRIORITY, eRange, true)

VP = VPrediction()

config = scriptConfig("AutoRengar: Resurrected", "Rengar")

config:addSubMenu("Rengar: Empowered Control", "empCont")
config:addSubMenu("Rengar: Harass Settings", "harass")
config:addSubMenu("Rengar: Drawing Settings", "drawing")

config:addParam("delete", "Combo Key", SCRIPT_PARAM_ONKEYDOWN, false, string.byte(" "))
config:addParam("harassk", "Harass Key", SCRIPT_PARAM_ONKEYDOWN, false, string.byte("C"))
config:addParam("autoCombo", "Combo automatically in midair", SCRIPT_PARAM_ONOFF, true)
config:addParam("Ignite", "Automatically Ignite", SCRIPT_PARAM_ONOFF, true)

config.drawing:addParam("draw", "Draw circles+text", SCRIPT_PARAM_ONOFF, true)
config.drawing:addParam("drawE", "Draw E range", SCRIPT_PARAM_ONOFF, true)
config.drawing:addParam("drawW", "Draw W range", SCRIPT_PARAM_ONOFF, true)

config.empCont:addParam("dontEmpE", "Dont use E at 5 stacks", SCRIPT_PARAM_ONOFF, true)
config.empCont:addParam("autoheal", "Auto Heal if low", SCRIPT_PARAM_SLICE, 25,0,100,0)
config.empCont:addParam("autoEmpQ", "Auto 5stack Q", SCRIPT_PARAM_ONOFF, true)

config.harass:addParam("UseE", "Use E in harass", SCRIPT_PARAM_ONOFF, true)
config.harass:addParam("UseW", "Use W in harass", SCRIPT_PARAM_ONOFF, true)

print("Fret's AutoRengar:Resurrected (v1.4) ...<font> <font color = \"#FF0000\">Loaded! </font>")

if myHero:GetSpellData(SUMMONER_1).name:find("summonerdot") then ign = SUMMONER_1
	elseif myHero:GetSpellData(SUMMONER_2).name:find("summonerdot") then ign = SUMMONER_2
		else ign = nil
end
LoadOrbwalker()
end

local count = 0

function LoadOrbwalker()
   if _G.Reborn_Initialised then
      print("AutoRengar: Reborn loaded and authed")
			isSac = true
			loaded = true
			config:addSubMenu("Rengar: Orbwalker", "Orbwalker")
			config.Orbwalker:addParam("info", "SAC:R detected", SCRIPT_PARAM_INFO, "")
   elseif _G.Reborn_Loaded and not _G.Reborn_Initialised and count < 30 then
			if printedWaiting == false then
      print("AutoRengar: Waiting for Reborn auth")
			printedWaiting = true
			end
      DelayAction(LoadOrbwalker, 1)
			count = count + 1
   else
			if count >= 30 then
			print("AutoRengar: SAC failed to auth")
			end
			require 'SxOrbWalk'
      print("SxOrbWalk: Loading...")
				config:addSubMenu("Rengar: Orbwalker", "Orbwalker")
				SxOrb:LoadToMenu(config.Orbwalker)
				isSx = true
			print("SxOrbWalk: Loaded")
			loaded = true
   end
end

function OnTick() --=======================ONTICK============ONTICK========--
	ts:update()
	target = ts.target
	Ignite()
	GetItemSlot()
	fHydra()
	
	if isSx then
	SxOrb:ForceTarget(target)
	elseif isSac then
	target = _G.AutoCarry.Crosshair:GetTarget()
	end
	AutoQ()
	AutoHeal()
	calcRange()
	isEmpowered()
	CastW()
	Harass()
	autoCombo()
	tripleQ()
	instantWE()
	fury = myHero.mana
	SpamE()
end

function OnDraw() -- ONDRAW  ONDRAW  ONDRAW  ONDRAW  ONDRAW  ONDRAW  ONDRAW  ONDRAW
	if config.drawing.draw then
		if ValidTarget(target) then
			DrawCircle(target.x, target.y, target.z, 200, 0xffffff)
		end
		if config.drawing.drawE and CanCast(_E) then
			DrawCircle(myHero.x, myHero.y, myHero.z, eRange, 0xFFFF0000)
		end
		if config.drawing.drawW and CanCast(_W) then
			DrawCircle(myHero.x, myHero.y,myHero.z, 500, 0xFFFF0000)
		end
	end	
end

local fury = myHero.mana

function autoCombo()
	if config.autoCombo and ValidTarget(target, 500) and myHero.y > 90 and config.delete then
		if CanCast(_Q) then CastSpell(_Q) end
		if CanCast(_E) and myHero.mana < 5 then CastSpell(_E, target.x, target.z) end
		if Hydra and CanCast(Hydra) and GetDistance(target) < 200 then CastSpell(Hydra) end
		if BORK and CanCast(BORK) then CastSpell(BORK, target) end
		if Ghostblade and CanCast(Ghostblade) then CastSpell(Ghostblade) end
	end	
end

function tripleQ()
	if config.delete and ValidTarget(target, leapRange) then
		if CanCast(_Q) then CastSpell(_Q) myHero:Attack(target) end
	end	
end

function instantWE()
	if config.delete and config.combo then
		if CanCast(_W) and ValidTarget(target, 500) then CastSpell(_W) end
		if CanCast(_E) and ValidTarget(target, eRange) then 
			local CastPosition,  HitChance,  Position = VP:GetLineCastPosition(ts.target, 0, 80, eRange, 2.25, myHero, true)
			if HitChance >= 2 and GetDistance(ts.target) <= eRange and myHero.mana < 5 then
				CastSpell(_E, CastPosition.x,CastPosition.z)
			end
		end
	end
end

function AutoQ()
	if config.delete and not isSnare and ValidTarget(target, (qRange)) and fury == 5 and CanCast(_Q) then
		CastSpell(_Q) 
		myHero:Attack(target)
	end
end	

function AutoHeal()
if myHero.health <= myHero.maxHealth/100*config.empCont.autoheal and myHero.mana == 5 and CanCast(_W) then CastSpell(_W) end
end

local qRange = myHero.range
local Visible = true

function calcRange()
if myHero.range > 150 and myHero.range < 700 then leapRange = myHero.range+175 Visible = false end
if myHero.range >150 and myHero.range >= 700 then leapRange = myHero.range+75 Visible = false end
if myHero.range < 150 then leapRange = 190 Visible = true end
qRange = leapRange+25
end

function CanCast(Spell)
return (myHero:CanUseSpell(Spell) == READY)
end

function isEmpowered()
	if ValidTarget(target) and fury == 5 and config.empCont.AutoEmpQ and not isSnare then
		local Dist = GetDistance(target)
		if Dist < leapRange then
			CastSpell(_Q)
			myHero:Attack(target)
		end
	end
end

function CastW()
if config.delete and ValidTarget(target, 500) and myHero.mana < 5 and CanCast(_W) and Visible then
	CastSpell(_W)
end
end

function Harass()
	if config.harassk and Visible then
		if config.harass.UseW and ValidTarget(target, 500) and CanCast(_W) and myHero.mana then
			CastSpell(_W)
		end
		if config.harass.UseE	and CanCast(_E) and ValidTarget(target, eRange) then
			local CastPosition,  HitChance,  Position = VP:GetLineCastPosition(ts.target, 0, 80, eRange, 2.25, myHero, true)
			if HitChance >= 2 and GetDistance(ts.target) <= eRange and myHero.mana < 5 then
				CastSpell(_E, CastPosition.x,CastPosition.z)
			end
		end
	end
end

local Hydra
local Ghostblade
local BORK

function GetItemSlot()
	for slot = ITEM_1, ITEM_7 do
		local currentItemName = myHero:GetSpellData(slot).name
		if currentItemName == "ItemTiamatCleave" then
		Hydra = slot
		elseif currentItemName  == "YoumusBlade" then
		Ghostblade = slot
		elseif currentItemName == "ItemSwordOfFeastAndFamine" then
		BORK = slot
		elseif currentItemName == "BilgewaterCutlass" then
		BORK = slot
		end
	end
end

function fHydra()
	if ValidTarget(target) and Hydra and CanCast(Hydra) and config.delete and GetDistance(target) < 200 then
		if SxOrb then
			if SxOrb:CanMove() then
				CastSpell(Hydra)
			end
		elseif isSac then
			if not _G.AutoCarry.Orbwalker:IsShooting() and GetDistance(target) < 200 then
				CastSpell(Hydra)
			end
		end	
	end
end

function Ignite()
	if config.Ignite and ign ~= nil and CanCast(ign) then
		local igniteDamage = 50 + 20 * myHero.level
    for i = 1, heroManager.iCount, 1 do
      local target = heroManager:getHero(i)
      if ValidTarget(target, 600) and target.team ~= myHero.team then
        if igniteDamage > (target.health - 25) then
          CastSpell(ign, target)
        end
      end
    end
  end
end

function SpamE()
if myHero.y > 120 and CanCast(_E) and ValidTarget(target) and config.delete then
CastSpell(_E, target.x, target.z)
end
end
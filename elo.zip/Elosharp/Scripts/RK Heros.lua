--[[ Script AutoUpdater ]]
local version = "2.5"
local author = "RK1K"
local SCRIPT_NAME = "RK_Heros"
local AUTOUPDATE = true
local ran = math.random
local UPDATE_HOST = "raw.githubusercontent.com"
local UPDATE_PATH = "/RK1K/RKScriptFolder/master/RK%20Heros.lua".."?rand="..ran(3500,5500)
local UPDATE_FILE_PATH = SCRIPT_PATH..GetCurrentEnv().FILE_NAME
local UPDATE_URL = "https://"..UPDATE_HOST..UPDATE_PATH

if FileExist(LIB_PATH .. "/CastItems.lua") then
	require "CastItems"
else
    print("Downloading Librarys...")
    DelayAction(function() DownloadFile("https://raw.githubusercontent.com/Icesythe7/GOS/master/CastItems.lua".."?rand="..ran(1500,2500), LIB_PATH.."CastItems.lua", function () print("Successfully downloaded, SHIFT + double-press F9.") end) end, 3)
    return
end

local mh = myHero
local tu = table.unpack
local champ = mh.charName
local aka = champ == "Akali"
local amu = champ == "Amumu"
local blit = champ == "Blitzcrank"
local evel = champ == "Evelynn"
local fiz = champ == "Fizz"
local heca = champ == "Hecarim"
local jin = champ == "Jhin"
local kasa = champ == "Kassadin"
local kay = champ == "Kayle"
local liss = champ == "Lissandra"
local nas = champ == "Nasus"
local nunu = champ == "Nunu"
local orn = champ == "Ornn"
local pha = champ == "Pantheon"
local ram = champ == "Rammus"
local sha = champ == "Shaco"
local sing = champ == "Singed"
local tem = champ == "Teemo"
local tri = champ == "Tristana"
local vlad = champ == "Vladimir"
local xinn = champ == "Xin Zhao"

function OnLoad() Update() Simple()
	if aka then MenuAkali()
	elseif amu then MenuAmumu()
	elseif blit then MenuBlitzcrank()
	elseif evel then MenuEvelynn()
	elseif fiz then MenuFizz()
	elseif heca then MenuHecarim()
	elseif jin then MenuJhin()
	elseif kasa then MenuKassadin()
	elseif kay then MenuKayle()
	elseif liss then MenuLissandra()
	elseif nas then MenuNasus()
	elseif nunu then MenuNunu()
	elseif orn then MenuOrnn()
	elseif pha then MenuPantheon()
	elseif ram then MenuRammus()
	elseif sha then MenuShaco()
	elseif sing then MenuSinged()
	elseif tem then MenuTeemo()
	elseif tri then MenuTristana()
	elseif vlad then MenuVladimir()
	end
end

function MenuAkali()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Akarry</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Akarry", "RK Heros -- Akarry")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1200, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 340, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 600, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 250, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 320, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 700, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"R > Q > E", "R > E > Q", "Q > E > R", "Q > R > E", "E > Q > R", "E > R > Q"})
		cfg.combo:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("erange", "Cast E if enemy < Hero *320", SCRIPT_PARAM_SLICE, 320,310,330)
		cfg.combo:addParam("23","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN,false, GetKey("T"))
		cfg.combo:addParam("rdis","R Distance 1 / 2", SCRIPT_PARAM_ONKEYTOGGLE,false, GetKey("N"))
		cfg.combo:addParam("rrange", "1 | Cast R if enemy > Hero", SCRIPT_PARAM_SLICE, 710,50,710)
		cfg.combo:addParam("rrangee", "2 | Cast R if enemy > Hero", SCRIPT_PARAM_SLICE, 400,50,710)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,2,{"R > Q > E", "R > E > Q", "Q > E > R", "Q > R > E", "E > Q > R", "E > R > Q"})
		cfg.harass:addParam("35","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("ehrange", "Cast E if enemy < Hero *320", SCRIPT_PARAM_SLICE, 320,310,330)
		cfg.harass:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("rrange", "Cast R if enemy > Hero", SCRIPT_PARAM_SLICE, 500,50,710)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)

	cfg:addSubMenu("Script | W Logic","wlo")
		cfg.wlo:addParam("mode","W mode",SCRIPT_PARAM_LIST,1,{"To Target", "Myself"})
		cfg.wlo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.wlo:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 400,100,1000)
		cfg.wlo:addParam("wauto", "W on enemy amount", SCRIPT_PARAM_SLICE, 1,1,5)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.combo:permaShow("rdis")
		cfg.combo:permaShow("rrange")
		cfg.combo:permaShow("rrangee")
		cfg.combo:permaShow("23")
		cfg.harass:permaShow("mode")
		cfg.wlo:permaShow("mode")
		cfg.wlo:permaShow("wauto")
	end
end
function MenuAmumu()
		DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Amumu</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Amumu", "RK Heros -- Amumu")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1200, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 350, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 1100, Width = 50, Delay = 0.25, Speed = 2000, Collision = true, Aoe = false, Type = SPELL_TYPE.LINEAR}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 300, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 350, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 550, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("rrange", "Cast R if enemy < Hero 550*", SCRIPT_PARAM_SLICE, 550,540,560)
		cfg.combo:addParam("renemy", "Cast R on enemy amount", SCRIPT_PARAM_SLICE, 1,1,5)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	cfg:addSubMenu("Script | Auto R","auto")
		cfg.auto:addParam("rauto","R usage",SCRIPT_PARAM_ONOFF,true)
		cfg.auto:addParam("rautoe", "Auto R on enemy amount", SCRIPT_PARAM_SLICE, 4,1,5)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("renemy")
		cfg.auto:permaShow("rautoe")
	end
end
function MenuBlitzcrank()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Blitzy</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Blitzy", "RK Heros -- Blitzy")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1300, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 1000, mh,MINION_SORT_HEALTH_ASC)

	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 1000, Width = 70, Delay = 0.25, Speed = 1800, Aoe = false, Collision = true, Type = SPELL_TYPE.LINEAR}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	R = _Spell({Slot = _R, DamageName = "R", Range = 600, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin", "Support"})
		cfg.combo:addParam("0","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 500,100,1000)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("rrange", "Cast R if enemy < 590 Hero", SCRIPT_PARAM_SLICE, 590,570,620)
		cfg.combo:addParam("renemy", "Cast R on enemy amount", SCRIPT_PARAM_SLICE, 1,1,5)
		cfg.combo:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rpasive","Draw R pasive",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("panicr", "Use R when life under %", SCRIPT_PARAM_SLICE, 10,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin", "Support"})
		cfg.harass:addParam("6","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 500,100,1000)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	cfg:addSubMenu("Script | Auto R","auto")
		cfg.auto:addParam("rauto","Auto R usage",SCRIPT_PARAM_ONOFF,true)
		cfg.auto:addParam("rautoe", "Auto R on enemy amount", SCRIPT_PARAM_SLICE, 4,1,5)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.combo:permaShow("renemy")
		cfg.harass:permaShow("mode")
		cfg.auto:permaShow("rautoe")
	end
end
function MenuEvelynn()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Evelynn</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Evelynn", "RK Heros -- Evelynn")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1600, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 340, mh,MINION_SORT_HEALTH_ASC)
	
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 800, Width = 80, Delay = 0.25, Speed = 1600, Aoe = false, Collision = true, Type = SPELL_TYPE.LINEAR}):AddDraw()
    W = _Spell({Slot = _W, DamageName = "W", Range = 1600, Type = SPELL_TYPE.TARGETTED}):AddDraw()
    E = _Spell({Slot = _E, DamageName = "E", Range = 250, Type = SPELL_TYPE.TARGETTED}):AddDraw()
    R = _Spell({Slot = _R, DamageName = "R", Range = 450, Width = 400, Delay = 0.25, Speed = 1600, Aoe = true, Collision = false, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
    Ignite = _Spell({Slot = FindSummonerSlot("summonerdot"), DamageName = "IGNITE", Range = 600, Type = SPELL_TYPE.TARGETTED})

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Pasives","draws")
		cfg.draws:addParam("ecolor","Stealth Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("equal","Stealth Quality", SCRIPT_PARAM_SLICE,1,3,1)
		cfg.draws:addParam("qcolor","Q pasive Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("qqual","Q pasive Quality", SCRIPT_PARAM_SLICE,1,3,1)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wrange", "Cast W if enemy < Hero *1600", SCRIPT_PARAM_SLICE, 700,1600,100)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("eaim","E Aimed", SCRIPT_PARAM_ONKEYDOWN,false, GetKey("S"))
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN,false, GetKey("T"))

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 30,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < Hero *1600", SCRIPT_PARAM_SLICE, 900,1600,100)
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
end
function MenuFizz()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Fizzor</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Fizzor", "RK Heros -- Fizzor")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 600, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 550, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 400, Width = 330, Delay = 0.25, Speed = 1200, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 1275, Width = 150, Delay = 0.25, Speed = 1300, Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Fizzor", "Bruiser"})
		cfg.combo:addParam("0","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wrange", "Cast W if enemy < 330 Hero", SCRIPT_PARAM_SLICE, 330,300,500)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
 		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("T"))

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Fizzor"})
		cfg.harass:addParam("6","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whrange", "Cast W if enemy < 320 Hero", SCRIPT_PARAM_SLICE, 320,300,500)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.harass:permaShow("mode")
	end
end
function MenuHecarim()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Heka</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Heka", "RK Heros -- Heka")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 500, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 350, Width = 0, Delay = 0 , Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 525, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	R = _Spell({Slot = _R, DamageName = "R", Range = 1000, Width = 250, Delay = 0.25, Speed = 800, Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin"})
		cfg.combo:addParam("0","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("qrange", "Cast Q if enemy < Hero", SCRIPT_PARAM_SLICE, 340,330,360)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 520,500,550)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("erange", "Cast E if enemy < Hero", SCRIPT_PARAM_SLICE, 750,500,1000)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin"})
		cfg.harass:addParam("6","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("qrange", "Cast Q if enemy < Hero", SCRIPT_PARAM_SLICE, 340,330,360)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 520,500,550)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("erange", "Cast E if enemy < Hero", SCRIPT_PARAM_SLICE, 600,500,1000)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.harass:permaShow("mode")
	end
end
function MenuJhin()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Jhin</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Jhin", "RK Heros -- Jhin")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 3600, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 3600, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 610, Width = 450, Delay = 0.25 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 2500, Width = 40, Delay = 0.75, Collision = false, Aoe = false, Type = SPELL_TYPE.LINEAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 750, Width = 135, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 3500, Width = 80, Delay = 0.2, Speed = 5000, Collision = true, Aoe = false, Type = SPELL_TYPE.LINEAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("waim","W Aimed", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("S"))
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("T"))

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("qusage")
		cfg.combo:permaShow("wusage")
		cfg.combo:permaShow("eusage")
		cfg.combo:permaShow("2")
		cfg.combo:permaShow("waim")
		cfg.combo:permaShow("raim")
	end
end
function MenuKassadin()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Kasi Dongo</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Kasi Dongo", "RK Heros -- Kasi Dongo")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1000, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 800, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 650, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 580, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 700, Width = 0, Delay = 0.15, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Kassasin", "Interrupter"})
		cfg.combo:addParam("0","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wrange", "Cast W if enemy < 330 Hero", SCRIPT_PARAM_SLICE, 330,300,500)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("erange", "Cast E if enemy < 625 Hero", SCRIPT_PARAM_SLICE, 625,600,650)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Kassasin"})
		cfg.harass:addParam("6","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whrange", "Cast W if enemy < 320 Hero", SCRIPT_PARAM_SLICE, 320,300,500)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("ehrange", "Cast E if enemy < 610 Hero", SCRIPT_PARAM_SLICE, 610,600,650)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.combo:permaShow("rusage")
		cfg.harass:permaShow("mode")
	end
end
function MenuKayle()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Kayle</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Kayle", "RK Heros -- Kayle")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1000, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 1000, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 650, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 900, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	R = _Spell({Slot = _R, DamageName = "R", Range = 900, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("waim","Auto W on my Hero", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("S"))
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("raim","Auto R on my Hero", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("T"))
		cfg.combo:addParam("panicr", "Use on me R when life under %", SCRIPT_PARAM_SLICE, 5,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("waim")
		cfg.combo:permaShow("raim")
		cfg.combo:permaShow("panicr")
	end
end
function MenuLissandra()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Lissandra</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Lissandra", "RK Heros -- Lissandra")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 1200, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 725, Width = 0, Delay = 0 , Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 450, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 1050, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 550, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.TARGETTED}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin"})
		cfg.combo:addParam("0","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 445,430,470)
		cfg.combo:addParam("wenemy", "Cast W on enemy amount", SCRIPT_PARAM_SLICE, 1,1,5)
		cfg.combo:addParam("autow","Auto W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wauto", "Auto W on enemy amount", SCRIPT_PARAM_SLICE, 2,1,5)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("T"))
		cfg.combo:addParam("panicr", "Use on me R when life under %", SCRIPT_PARAM_SLICE, 10,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Optimal", "Assasin"})
		cfg.harass:addParam("6","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < Hero", SCRIPT_PARAM_SLICE, 450,430,470)
		cfg.harass:addParam("wenemy", "Cast W on enemy amount", SCRIPT_PARAM_SLICE, 2,1,5)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.harass:permaShow("mode")
	end
end
function MenuNasus()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Nasus</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Nasus", "RK Heros -- Nasus")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1000, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 800, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 0, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	W = _Spell({Slot = _W, DamageName = "W", Range = 600, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 650, Width = 500, Delay = 0.5, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("rpeop", "Cast R if enemys >=", SCRIPT_PARAM_SLICE, 2,1,5)
		cfg.combo:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("peop","Panic R only if enemys near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("rpanic", "Panic R if life < %", SCRIPT_PARAM_SLICE, 15,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("rpeop")
		cfg.combo:permaShow("peop")
		cfg.combo:permaShow("rpanic")
	end
end
function MenuNunu()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Nunu</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Nunu", "RK Heros -- Nunu")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1000, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 600, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 125, Width = 0, Delay = 0.5 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED})
	W = _Spell({Slot = _W, DamageName = "W", Range = 700, Width = 0, Delay = 0.5, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 550, Width = 0, Delay = 0.55, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 650, Width = 0, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 5,0,100)
		cfg.combo:addParam("wrange", "Cast W if enemy < 300 Hero", SCRIPT_PARAM_SLICE, 300,100,1500)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("rrange", "Cast R if enemy < 640 Hero", SCRIPT_PARAM_SLICE, 640,600,700)
		cfg.combo:addParam("renemy", "Cast R on enemy amount", SCRIPT_PARAM_SLICE, 1,1,5)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 5,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < 400 Hero", SCRIPT_PARAM_SLICE, 400,100,1500)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("wrange")
		cfg.combo:permaShow("renemy")
	end
end
function MenuOrnn()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Ornn</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Ornn", "RK Heros -- Ornn")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 2500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 800, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 800, Width = 150, Delay = 0.25 , Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 400, Width = 0, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 800, Width = 300, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 2500, Width = 900, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.LINEAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 5,0,100)
		cfg.combo:addParam("wrange", "Cast W if enemy < 400 Hero", SCRIPT_PARAM_SLICE, 400,350,450)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN,false, GetKey("T"))
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 5,0,100)
		cfg.harass:addParam("wrange", "Cast W if enemy < 400 Hero", SCRIPT_PARAM_SLICE, 400,350,450)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
end
function MenuPantheon()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Pantheon</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Pantheon", "RK Heros -- Pantheon")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_NEAR_MOUSE, 5600, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 700, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 600, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 600, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 600, Width = 0, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 5500, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("erange", "Cast E if enemy < Hero", SCRIPT_PARAM_SLICE, 300,100,600)
		cfg.combo:addParam("eaim","E key on enemy", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("S"))
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("raim","R key on Target", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("T"))

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("4","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("whmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("5","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehmana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("ehrange", "Cast E if enemy < Hero", SCRIPT_PARAM_SLICE, 450,100,600)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("wrange")
		cfg.combo:permaShow("renemy")
	end
end
function MenuRammus()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Bowser</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Bowser", "RK Heros -- Bowser")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 350, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 0, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 325, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 300, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()

	cfg:addTS(TS)
		cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qrange", "Q Detection Radious", SCRIPT_PARAM_SLICE, 700,200,2000)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wrange", "C| W Detection Radious", SCRIPT_PARAM_SLICE, 500,200,1500)
		cfg.combo:addParam("wpeop", "C| Cast W if ammunt enemy radious >", SCRIPT_PARAM_SLICE, 1,1,5)
		cfg.combo:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("3","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("rpeop", "C| Cast R if amount enemy >", SCRIPT_PARAM_SLICE, 1,1,5)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qrange", "Q Detection Radious", SCRIPT_PARAM_SLICE, 700,200,2000)
		cfg.harass:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("wusage","Cast W if enemy near",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.harass:addParam("wrange", "W Detection Radious", SCRIPT_PARAM_SLICE, 500,200,1500)
		cfg.harass:addParam("wpeop", "H| W if amount enemy radious >", SCRIPT_PARAM_SLICE, 1,1,5)
		cfg.harass:addParam("2","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

	cfg:addSubMenu("Script | Auto","auto")
		cfg.auto:addParam("waim","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.auto:addParam("wrange", "W if enemy < Hero ", SCRIPT_PARAM_SLICE, 500,200,1500)
		cfg.auto:addParam("wauto", "A| W if amount enemy radious >", SCRIPT_PARAM_SLICE, 3,1,5)
		cfg.auto:addParam("1","",SCRIPT_PARAM_INFO,"")
		cfg.auto:addParam("raim","R usage",SCRIPT_PARAM_ONOFF,true)
		cfg.auto:addParam("rauto", "A| R if amount enemy radious >", SCRIPT_PARAM_SLICE, 3,1,5)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("wrange")
		cfg.combo:permaShow("wpeop")
		cfg.combo:permaShow("rpeop")
		cfg.combo:permaShow("2")
		cfg.harass:permaShow("wpeop")
		cfg.combo:permaShow("2")
		cfg.auto:permaShow("wauto")
		cfg.auto:permaShow("rauto")
	end
end
function MenuShaco()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Shaco Paco</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Shaco Paco", "RK Heros -- Shaco Paco")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1725, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 650, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 400, Delay = 0.25 , Collision = false, Aoe = false, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 425, Width = 300, Delay = 0.5, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 625, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 0, Width = 0, Delay = 0.25, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
	cfg.sett:addParam("idioma","Script Language; Reload with 2x F9 ",SCRIPT_PARAM_LIST,1,{"English","Spanish","Catala"})
	cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
	cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)
local idi = cfg.sett.idioma
if idi == 1 then
	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Go to Keys","moto")
		cfg.moto:addParam("motousage","ON / OFF Go to Keyblinds",SCRIPT_PARAM_ONOFF,false)
		cfg.moto:addParam("basekey","Go to Own Base", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("N"))
		cfg.moto:addParam("tblue","Go to Top Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("G"))
		cfg.moto:addParam("bblue","Go to Bot Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("K"))
		cfg.moto:addParam("tred","Go to Top Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("L"))
		cfg.moto:addParam("bred","Go to Bot Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("J"))

	cfg:addSubMenu("Target Draws","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Shaco Draws","draws")
		cfg.draws:addParam("hitbox","Draw Shaco Hitbox",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1","Set Hitbox Density",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color","Set Hitbox Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD","Set Hitbox Resolution",SCRIPT_PARAM_SLICE,5,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("Qmaxspot","Draw Q Spot",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1Q","Set Q Spot Density",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("ColorQ","Set Q Spot Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityDQ","Set Q Spot Quality",SCRIPT_PARAM_SLICE,6,3,100)
		cfg.draws:addParam("SizeQ","Set Q Spot Size",SCRIPT_PARAM_SLICE,40,20,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("rrange","Draw R Range",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality12","Set R Range Density",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color2","Set R Range Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD2","Set R Range Quality",SCRIPT_PARAM_SLICE,10,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("walljumps","Draw Q Jump Points",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("QualityJ","Set Q Jump Density",SCRIPT_PARAM_SLICE,2,1,5)
		cfg.draws:addParam("ColorJ","Set Q Jump Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("SizeJ","Set Q Jump Size",SCRIPT_PARAM_SLICE,75,20,100)
		cfg.draws:addParam("FatJ","Set Q Jump Quality",SCRIPT_PARAM_SLICE,30,3,100)

		cfg:addSubMenu("Script | LaneClear","clear")
			cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
			cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
			cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

		cfg:addSubMenu("Script | JungleClear","jungle")
			cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
			cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
			cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

		cfg:addParam("eusage","ON / OFF E usage",SCRIPT_PARAM_ONOFF,true)
		cfg:addParam("emana", "Use E if mana Shaco > %", SCRIPT_PARAM_SLICE, 5,0,100)
end
if idi == 2 then
	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)

		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)

		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Ir a Teclas","moto")
		cfg.moto:addParam("motousage","ON / OFF Ir a Teclas",SCRIPT_PARAM_ONOFF,false)
		cfg.moto:addParam("basekey","Ir a Own Base", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("N"))
		cfg.moto:addParam("tblue","Ir a Top Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("G"))
		cfg.moto:addParam("bblue","Ir a Bot Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("K"))
		cfg.moto:addParam("tred","Ir a Top Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("L"))
		cfg.moto:addParam("bred","Ir a Bot Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("J"))

	cfg:addSubMenu("Dibujos del Enemigo","draw")
		cfg.draw:addParam("target", "Dibujar un circulo en el Objetivo", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Color del Objetivo",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Radio del Circulo", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Amplitud del Circulo",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Dibujar Texto del Objetivo ", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Posicion del texto = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Tamano del texto",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Posicion Vertical del texto", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Posicion Horizontal del texto", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Color del texto",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","Restablecer por defecto",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Dibujos de Shaco","draws")
		cfg.draws:addParam("hitbox","Shaco Hitbox",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1","Hitbox Densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color","Hitbox Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD","Hitbox Resolucion",SCRIPT_PARAM_SLICE,5,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("Qmaxspot","Mostrar QSpot",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1Q","Q Spot Densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("ColorQ","Q Spot Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityDQ","Q Spot Calidad",SCRIPT_PARAM_SLICE,6,3,100)
		cfg.draws:addParam("SizeQ","Q Spot Tamano",SCRIPT_PARAM_SLICE,40,20,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("rrange","Mostrar Rango R",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality12","Rango R Densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color2","Rango R Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD2","Rango R Calidad",SCRIPT_PARAM_SLICE,10,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("walljumps","Mostrar Q Jump puntos",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("QualityJ","Q Jump Densidad",SCRIPT_PARAM_SLICE,2,1,5)
		cfg.draws:addParam("ColorJ","Q Jump Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("SizeJ","Q Jump Tamano",SCRIPT_PARAM_SLICE,75,20,100)
		cfg.draws:addParam("FatJ","Q Jump Calidad",SCRIPT_PARAM_SLICE,30,3,100)

		cfg:addSubMenu("Script | LaneClear","clear")
			cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
			cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
			cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

		cfg:addSubMenu("Script | JungleClear","jungle")
			cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
			cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
			cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

		cfg:addParam("eusage","ON / OFF Uso de E en Combo",SCRIPT_PARAM_ONOFF,true)
		cfg:addParam("emana", "Usar E si mana Shaco > %", SCRIPT_PARAM_SLICE, 5,0,100)
	end

if idi == 3 then
	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 20,0,100)

		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)

		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Anar a Teclas","moto")
		cfg.moto:addParam("motousage","ON / OFF Anar a Teclas",SCRIPT_PARAM_ONOFF,false)
		cfg.moto:addParam("basekey","Anar a la Base", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("N"))
		cfg.moto:addParam("tblue","Anar a Top Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("G"))
		cfg.moto:addParam("bblue","Anar a Bot Blue", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("K"))
		cfg.moto:addParam("tred","Anar a Top Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("L"))
		cfg.moto:addParam("bred","Anar a Bot Red", SCRIPT_PARAM_ONKEYDOWN, false, GetKey("J"))

	cfg:addSubMenu("Dibuix del Objectiu","draw")
		cfg.draw:addParam("target", "Dubuixa el objectiu", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Cercle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Cercle Radi", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Cercle Amplitud",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Dibuix del objectiu amb texte", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Posicio del texte = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Tamany del texte",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Posicio vertical del texte", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Posicio horitzontal del texte", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Color del texte",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","Reinici per defecte",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Dibuixos de Shaco","draws")
		cfg.draws:addParam("hitbox","Mostra Shaco Hitbox",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1","Aplica Hitbox densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color","Aplica Hitbox Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD","Aplica Hitbox resolucio",SCRIPT_PARAM_SLICE,5,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("Qmaxspot","Mostra Q Spot",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality1Q","Aplica Q Spot densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("ColorQ","Aplica Q Spot Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityDQ","Aplica Q Spot resolucio",SCRIPT_PARAM_SLICE,6,3,100)
		cfg.draws:addParam("SizeQ","Aplica Q Spot Size",SCRIPT_PARAM_SLICE,40,20,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("rrange","Mostra R Range",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("Quality12","Aplica R Range densidad",SCRIPT_PARAM_SLICE,1,1,5)
		cfg.draws:addParam("Color2","Aplica R Range Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("QualityD2","Aplica R Range resolucio",SCRIPT_PARAM_SLICE,10,3,100)

			cfg.draws:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg.draws:addParam("walljumps","Mostra Q Jump Points",SCRIPT_PARAM_ONOFF,false)
		cfg.draws:addParam("QualityJ","Aplica Q Jump densidad",SCRIPT_PARAM_SLICE,2,1,5)
		cfg.draws:addParam("ColorJ","Aplica Q Jump Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draws:addParam("SizeJ","Aplica Q Jump Size",SCRIPT_PARAM_SLICE,75,20,100)
		cfg.draws:addParam("FatJ","Aplica Q Jump resolucio",SCRIPT_PARAM_SLICE,30,3,100)

		cfg:addSubMenu("Script | LaneClear","clear")
			cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
			cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
			cfg.clear:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,false)

		cfg:addSubMenu("Script | JungleClear","jungle")
			cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
			cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
			cfg.jungle:addParam("use","Tiamats",SCRIPT_PARAM_ONOFF,true)

		cfg:addParam("eusage","ON / OFF fer servir E",SCRIPT_PARAM_ONOFF,true)
		cfg:addParam("emana", "Fer servir E si mana Shaco > %", SCRIPT_PARAM_SLICE, 5,0,100)
	end
	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
end
function MenuSinged()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Singed</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Singed", "RK Heros -- Teemo")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1400, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 500, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 9, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	W = _Spell({Slot = _W, DamageName = "W", Range = 1000, Width = 375, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 300, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED})
	R = _Spell({Slot = _R, DamageName = "R", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})

	cfg:addTS(TS)
		cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("DRAW | Target","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("MODE | Combo","combo")
		cfg.combo:addParam("wusage","Set W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.combo:addParam("eusage","Set E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("MODE | Harass","harass")
		cfg.harass:addParam("wusage","Set W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.harass:addParam("eusage","Set E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
end
function MenuTeemo()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Teemo</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Teemo", "RK Heros -- Teemo")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1000, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 700, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 680, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	R = _Spell({Slot = _R, DamageName = "R", Range = 400, Width = 0, Delay = 0.25, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()

	cfg:addTS(TS)
		cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("DRAW | Target","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("MODE | Combo","combo")
		cfg.combo:addParam("qusage","Set Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("wusage","Set W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.combo:addParam("rusage","Set R usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("rmana", "Use R if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)

	cfg:addSubMenu("MODE | Harass","harass")
		cfg.harass:addParam("qhusage","Set Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhmana", "Use Q if mana > %", SCRIPT_PARAM_SLICE, 20,0,100)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
end
function MenuTristana()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Tristana</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	cfg = scriptConfig("RK Heros -- Tristana", "RK Heros -- Tristana")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1500, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 1000, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 0, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	W = _Spell({Slot = _W, DamageName = "W", Range = 900, Width = 450, Delay = 0.15, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()
	E = _Spell({Slot = _E, DamageName = "E", Range = 670, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 670, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.TARGETTED}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("DRAW | Target","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Use them when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("MODE | Combo","combo")
		cfg.combo:addParam("qusage","Set Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("qrange", "C| Cast Q if enemy < Hero 675*", SCRIPT_PARAM_SLICE, 675,550,800)
		cfg.combo:addParam("wusage","Set W usage",SCRIPT_PARAM_ONOFF,false)
		cfg.combo:addParam("wmana", "Use W if mana > %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.combo:addParam("wenemy", "Cast W if enemys less than", SCRIPT_PARAM_SLICE, 2,1,5)
		cfg.combo:addParam("eusage","Set E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("emana", "Use E if mana > %", SCRIPT_PARAM_SLICE, 0,0,100)
		cfg.combo:addParam("44","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("raim","R Aimed", SCRIPT_PARAM_ONKEYDOWN,false, GetKey("T"))

	cfg:addSubMenu("MODE | Harass","harass")
		cfg.harass:addParam("qhusage","Set Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("qhrange", "H| Cast Q if enemy < Hero 675*", SCRIPT_PARAM_SLICE, 675,550,800)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 50,0,100)
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("mana", "Use if Mana >", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.jungle:addParam("wusage","W usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("qrange")
		cfg.combo:permaShow("wenemy")
		cfg.harass:permaShow("qhrange")
	end
end
function MenuVladimir()
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Vladimiro</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Loaded succesfully !") end, 5)
	DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FFFFFF\">RK Vladimiro</font><font color=\"#000000\"> | </font></b><font color=\"#000FFF\"> Disable Q usage to prevent stop E de-charging / Or Manually use E Spell") end, 5)
	cfg = scriptConfig("RK Heros -- Vladimiro", "RK Heros -- Vladimiro")
	DelayAction(function() _arrangePriorities() end, 10)
	TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1200, DAMAGE_MAGIC)
	Minions = minionManager(MINION_ENEMY, 700, mh,MINION_SORT_HEALTH_ASC)
	Q = _Spell({Slot = _Q, DamageName = "Q", Range = 600, Width = 0, Delay = 0 , Collision = false, Aoe = false, Type = SPELL_TYPE.TARGETTED}):AddDraw()
	W = _Spell({Slot = _W, DamageName = "W", Range = 0, Width = 0, Delay = 0, Collision = false, Aoe = false, Type = SPELL_TYPE.SELF})
	E = _Spell({Slot = _E, DamageName = "E", Range = 610, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.SELF}):AddDraw()
	R = _Spell({Slot = _R, DamageName = "R", Range = 700, Width = 0, Delay = 0, Collision = false, Aoe = true, Type = SPELL_TYPE.CIRCULAR}):AddDraw()

	cfg:addTS(TS)
	cfg:addSubMenu(">>> Script Settings <<<", "sett")
		cfg.sett:addParam("logo","Script Logo; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addParam("perm","Script PermaShow; Reload with 2x F9",SCRIPT_PARAM_ONOFF,true)
		cfg.sett:addSubMenu("Orbwalker Settings", "Key")
		OrbwalkManager:LoadCommonKeys(cfg.sett.Key)

	cfg:addSubMenu("Draws | Target Selector","draw")
		cfg.draw:addParam("target", "Draw my Target with Circle", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("circlecolor","Circle Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("circleradius","Circle Radius", SCRIPT_PARAM_SLICE,70,30,100)
		cfg.draw:addParam("circlewidth","Circle Width",SCRIPT_PARAM_SLICE,3,1,15)
		cfg.draw:addParam("targettext", "Draw my Target as Text", SCRIPT_PARAM_ONOFF, true)
		cfg.draw:addParam("targettype", "Text Position = ", SCRIPT_PARAM_LIST, 1, {"Fix on Screen","On Mouse"})
		cfg.draw:addParam("targetsize","Text Size",SCRIPT_PARAM_SLICE,25,1,65)
		cfg.draw:addParam("TargetY", "Vertical Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1000,20)
		cfg.draw:addParam("TargetX", "Horizontal Position of the Text", SCRIPT_PARAM_SLICE, 50, 0, 1500,20)
		cfg.draw:addParam("targetcolor","Text Color",SCRIPT_PARAM_COLOR,{255, 255, 255, 255})
		cfg.draw:addParam("resetsettings","RSet Positions to default",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Items","items")
		cfg.items:addParam("panic", "Force use when life under %", SCRIPT_PARAM_SLICE, 20,0,100)
		cfg.items:addParam("11","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("22","<< Combo Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("ccut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("cgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("ctia","Tiamats",SCRIPT_PARAM_ONOFF,true)
		cfg.items:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("44","<< Harass Items >>",SCRIPT_PARAM_INFO,"")
		cfg.items:addParam("hcut","Bilgewater Cutlass",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hbok","Blade of the Ruined King",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("hgun","Hextech Gunblade",SCRIPT_PARAM_ONOFF,false)
		cfg.items:addParam("htia","Tiamats",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Combo","combo")
		cfg.combo:addParam("mode","Combo mode",SCRIPT_PARAM_LIST,1,{"Q > E", "E > Q"})
		cfg.combo:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.combo:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("panicw", "Use on me W when life under %", SCRIPT_PARAM_SLICE, 10,0,100)
		cfg.combo:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)
		cfg.combo:addParam("erange", "Cast E if enemy < 675 Hero", SCRIPT_PARAM_SLICE, 675,590,800)
		cfg.combo:addParam("rusage","R usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | Harass","harass")
		cfg.harass:addParam("mode","Harass mode",SCRIPT_PARAM_LIST,1,{"Q > E", "E > Q"})
		cfg.harass:addParam("33","",SCRIPT_PARAM_INFO,"")
		cfg.harass:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.harass:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)
		cfg.harass:addParam("ehrange", "Cast E if enemy < 660 Hero", SCRIPT_PARAM_SLICE, 660,590,800)

	cfg:addSubMenu("Script | LaneClear","clear")
		cfg.clear:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,false)
		cfg.clear:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,false)

	cfg:addSubMenu("Script | JungleClear","jungle")
		cfg.jungle:addParam("qusage","Q usage",SCRIPT_PARAM_ONOFF,true)
		cfg.jungle:addParam("eusage","E usage",SCRIPT_PARAM_ONOFF,true)

	if cfg.sett.logo then
		cfg:addParam("info","",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FFFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HHHHHH   FFFFFF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
		cfg:addParam("info3","             HH     HH   FF",SCRIPT_PARAM_INFO,"")
	end
	if cfg.sett.perm then
		cfg.combo:permaShow("mode")
		cfg.combo:permaShow("erange")
		cfg.combo:permaShow("panicw")
		cfg.combo:permaShow("33")
		cfg.harass:permaShow("mode")
		cfg.harass:permaShow("erange")
	end
end


function CheckMana(mana)
	if not mana then mana = 100 end
	if mh.mana / mh.maxMana > mana / 100 then
		return true
	else
		return false
	end
end

function Simple()
	local r = _Required()
	r:Add({Name = "SimpleLib", Url = "raw.githubusercontent.com/jachicao/BoL/master/SimpleLib.lua"})
	r:Check()
	if r:IsDownloading() then return end
end

function OnDraw()
	if evel then
		DrawCircle3D(mh.x, mh.y, mh.z, 680, cfg.draws.equal, ARGB(tu(cfg.draws.ecolor)))
		if mh:CanUseSpell(_Q) == READY then
		DrawCircle3D(mh.x, mh.y, mh.z, 600, cfg.draws.qqual, ARGB(tu(cfg.draws.qcolor)))
		end
	end
	if sha then ShacoDraws() end
	if blit and cfg.combo.rpasive and mh:CanUseSpell(_R) == READY then
		DrawCircle3D(mh.x, mh.y, mh.z, 450, cfg.draw.circlewidth , ARGB(tu(cfg.draw.circlecolor)))
	end
	if target then
		if cfg.draw.target then
			DrawCircle3D(target.x, target.y, target.z, cfg.draw.circleradius, cfg.draw.circlewidth , ARGB(tu(cfg.draw.circlecolor)))
		end
		if cfg.draw.targettext then
		local typ = cfg.draw.targettype
			if typ == 1 then
				FixOnScreenTarget()
			elseif typ == 2 then
				OnMouseTarget()
			end
		end
	end
end

function ShacoDraws()
	local qrdy = mh:CanUseSpell(_Q) == READY
	if cfg.draws.hitbox then
		DrawCircle3D(mh.x, mh.y, mh.z, 60, cfg.draws.Quality1, ARGB(tu(cfg.draws.Color)), cfg.draws.QualityD)
	end
	if cfg.draws.Qmaxspot and qrdy then
	local maxL = GetMaxLocation(400)
		DrawCircle3D(maxL.x, maxL.y, maxL.z, cfg.draws.SizeQ, cfg.draws.Quality1Q, ARGB(tu(cfg.draws.ColorQ)), cfg.draws.QualityDQ)
	end
	if cfg.draws.rrange and mh:CanUseSpell(_R) == READY then
		DrawCircle3D(mh.x, mh.y, mh.z, 2150, cfg.draws.Quality12, ARGB(tu(66, 134, 244)), cfg.draws.QualityD2)
	end
	if cfg.draws.walljumps and qrdy then
		local size = cfg.draws.SizeJ
		local cual = cfg.draws.QualityJ
		local color = cfg.draws.ColorJ
		local fat = cfg.draws.FatJ
		DrawCircle3D(8510, 52, 4698, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(8044, 52, 4264, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(5424, 52, 2956, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(5864, 52, 4354, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(6978, 52, 5618, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(8606, 52, 6766, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(11010, 52, 6376, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(10438, 52, 6494, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(12472, 52, 4508, size, cual, ARGB(tu(color)), fat)
		DrawCircle3D(10998, 52, 2526, size, cual, ARGB(tu(color)), fat)
	end
end

function GetMaxLocation(tR)
local mVector = Vector(mousePos.x, mousePos.z, mousePos.y)
local hVector = Vector(mh.x, mh.z, mh.y)
local bVector = ((mVector - hVector):normalized() * tR) + hVector
local theX, theZ, theY = bVector:unpack()
	return {x = theX, y = theY, z = theZ}
end

function ComboAkali()
local qq = cfg.combo.qusage
local ee = cfg.combo.eusage and CountEnemyHeroInRange(cfg.combo.erange, mh) > 0
local rr = cfg.combo.rusage and CountEnemyHeroInRange(cfg.combo.rrange, mh) > 0
local mod = cfg.combo.mode
	if mod == 1 then -- R > Q > E
		if rr then R:Cast(target) end
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
	elseif mod == 2 then -- R > E > Q
		if rr then R:Cast(target) end
		if ee then E:Cast(target) end
		if qq then Q:Cast(target) end
	elseif mod == 3 then -- Q > E > R
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 4 then -- Q > R > E
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 5 then -- E > Q > R
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 6 then -- E > R > Q
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if rr then R:Cast(target) end
	end
end
function ComboAmumu()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(340, mh) > 0)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana) and (CountEnemyHeroInRange(cfg.combo.rrange, mh) >= cfg.combo.renemy)
	if qq then Q:Cast(target) end
	if ee then E:Cast(target) end
	if rr then CastSpell(_R, mh) end
end
function ComboBlitzcrank()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(300, mh) > 0)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana) and (CountEnemyHeroInRange(cfg.combo.rrange, mh) >= cfg.combo.renemy)
local mod = cfg.combo.mode
	if mod == 1 then -- Optimal W > E > Q > R
		if ww then CastSpell(_W, mh) end
		if ee then CastSpell(_E, mh) end
		if qq then Q:Cast(target) end
		if rr then CastSpell(_R, mh) end
	elseif mod == 2 then -- Assasin R > Q > W > E
		if rr then CastSpell(_R, mh) end
		if ww then CastSpell(_W, mh) end
		if qq then Q:Cast(target) end
		if ee then CastSpell(_E, mh) end
	elseif mod == 3 then -- Support E > Q > W > R
		if ee then CastSpell(_E, mh) end
		if qq then Q:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if rr then CastSpell(_R, mh) end
	end
end
function ComboEvelynn()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
	if qq then Q:Cast(target) end
end
function ComboFizz()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
local mod = cfg.combo.mode
	if mod == 1 then -- W > E > Q > R
		if ww then CastSpell(_W, mh) end
		if ee then E:Cast(target) end
		if qq then Q:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 2 then -- R > Q > W > E
		if rr then R:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
	elseif mod == 3 then -- E > Q > W > R
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if rr then R:Cast(target) end
	end
end
function ComboHecarim()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana) and (CountEnemyHeroInRange(cfg.combo.qrange, mh) > 0)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(cfg.combo.erange, mh) > 0)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
local mod = cfg.combo.mode
	if mod == 1 then -- Optimal W > E > Q > R
		if ww then CastSpell(_W, mh) end
		if ee then CastSpell(_E, mh) end
		if qq then CastSpell(_Q, mh) end
		if rr then R:Cast(target) end
	elseif mod == 2 then -- Assasin R > W > Q > E
		if rr then R:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if qq then CastSpell(_Q, mh) end
		if ee then CastSpell(_E, mh) end
	end
end
function ComboJhin()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function ComboKassadin()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(cfg.combo.erange, mh) > 0)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
local mod = cfg.combo.mode
	if mod == 1 then -- W > E > Q > R
		if ww then CastSpell(_W, mh) end
		if ee then E:Cast(target) end
		if qq then Q:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 2 then -- R > Q > W > E
		if rr then R:Cast(target) end
		if qq then Q:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if ee then E:Cast(target) end
	elseif mod == 3 then -- Q > E > W > R
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if ww then CastSpell(_W, mh) end
		if rr then R:Cast(target) end
	end
end
function ComboKayle()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(670, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(670, mh) > 0)
	if qq then Q:Cast(target) end
	if ww then CastSpell(_W, mh) end
	if ee then CastSpell(_E, mh) end
end
function ComboLissandra()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) >= cfg.combo.wenemy)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
	if cfg.combo.mode == 1 then
		if ww then CastSpell(_W, mh) end
		if ee then CastSpell(_E, mh) end
		if qq then Q:Cast(target) end
		if rr then CastSpell(_R, mh) end
	elseif cfg.combo.mode == 2 then
		if rr then CastSpell(_R, mh) end
		if ww then CastSpell(_W, mh) end
		if qq then Q:Cast(target) end
		if ee then CastSpell(_E, mh) end
	end
end
function ComboNasus()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana) and (CountEnemyHeroInRange(mh.range+250, mh) > 0)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana) and (CountEnemyHeroInRange(700, mh) >= cfg.combo.rpeop)
	if qq then CastSpell(_Q, mh) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
	if rr then CastSpell(_R, mh) end
end
function ComboNunu()
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana) and (CountEnemyHeroInRange(cfg.combo.rrange, mh) >= cfg.combo.renemy)
	if ww then CastSpell(_W, mh) end
	if ee then E:Cast(target) end
	if rr then CastSpell(_R, mh) end
end
function ComboOrnn()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) > 0)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
	if rr then R:Cast(target) end
end
function ComboPantheon()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana) and (CountEnemyHeroInRange(cfg.combo.erange, mh) > 0)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function ComboRammus()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana) and (CountEnemyHeroInRange(cfg.combo.qrange, mh) > 0)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(cfg.combo.wrange, mh) >= cfg.combo.wpeop)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana) and (CountEnemyHeroInRange(350, mh) >= cfg.combo.rpeop)
	if qq then CastSpell(_Q, mh) end
	if ww then CastSpell(_W, mh) end
	if ee then E:Cast(target) end
	if rr then CastSpell(_R, mh) end
end
function ComboShaco()
local ee = cfg.eusage and CheckMana(cfg.emana)
	if ee then E:Cast(target) end
end
function ComboSinged()
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana)
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function ComboTeemo()
local qq = cfg.combo.qusage and CheckMana(cfg.combo.qmana)
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana)
local rr = cfg.combo.rusage and CheckMana(cfg.combo.rmana)
	if qq then Q:Cast(target) end
	if ww then CastSpell(_W, mh) end
	if rr then R:Cast(target) end
end
function ComboTristana()
local qq = cfg.combo.qusage and (CountEnemyHeroInRange(cfg.combo.qrange, mh) > 0 )
local ww = cfg.combo.wusage and CheckMana(cfg.combo.wmana) and (CountEnemyHeroInRange(1000, mh) < cfg.combo.wenemy )
local ee = cfg.combo.eusage and CheckMana(cfg.combo.emana)
	if qq then CastSpell(_Q, mh) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function ComboVladimir()
local qq = cfg.combo.qusage
local ee = cfg.combo.eusage and (CountEnemyHeroInRange(cfg.combo.erange, mh) > 0 )
local rr = cfg.combo.rusage
local mod = cfg.combo.mode
	if mod == 1 then
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
		if rr then R:Cast(target) end
	elseif mod == 2 then
		if ee then E:Cast(target) end
		if qq then Q:Cast(target) end
		if rr then R:Cast(target) end
	end
end


function HarassAkali()
local mod = cfg.harass.mode
local qh = cfg.harass.qusage
local eh = CountEnemyHeroInRange(cfg.harass.ehrange, mh) > 0 and cfg.harass.eusage
local rh = cfg.harass.rusage and CountEnemyHeroInRange(cfg.harass.rrange, mh) > 0
	if mod == 1 then -- R > Q > E
		if rh then R:Cast(target) end
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
	elseif mod == 2 then -- R > E > Q
		if rh then R:Cast(target) end
		if eh then E:Cast(target) end
		if qh then Q:Cast(target) end
	elseif mod == 3 then -- Q > E > R
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
		if rh then R:Cast(target) end
	elseif mod == 4 then -- Q > R > E
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
		if rh then R:Cast(target) end
	elseif mod == 5 then -- E > Q > R
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
		if rh then R:Cast(target) end
	elseif mod == 6 then -- E > R > Q
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
		if rh then R:Cast(target) end
	end
end
function HarassAmumu()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana) and (CountEnemyHeroInRange(340, mh) > 0)
	if qh then Q:Cast(target) end
	if eh then E:Cast(target) end
end
function HarassBlitzcrank()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local wh = cfg.harass.wusage and CheckMana(cfg.harass.whmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) > 0)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana)
local mod = cfg.harass.mode
	if mod == 1 then
		if wh then CastSpell(_W, mh) end
		if eh then CastSpell(_E, mh) end
		if qh then Q:Cast(target) end
	elseif mod == 2 then
		if qh then Q:Cast(target) end
		if wh then CastSpell(_W, mh) end
		if eh then CastSpell(_E, mh) end
	elseif mod == 3 then
		if eh then CastSpell(_E, mh) end
		if qh then Q:Cast(target) end
		if wh then CastSpell(_W, mh) end
	end
end
function HarassFizz()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local wh = cfg.harass.wusage and CountEnemyHeroInRange(cfg.harass.whrange, mh) > 0
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana)
local mod = cfg.harass.mode
	if mod == 1 then
		if wh then CastSpell(_W, mh) end
		if eh then E:Cast(target) end
		if qh then Q:Cast(target) end
	elseif mod == 2 then
		if qh then Q:Cast(target) end
		if wh then CastSpell(_W, mh) end
		if eh then E:Cast(target) end
	end
end
function HarassHecarim()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana) and (CountEnemyHeroInRange(cfg.harass.qrange, mh) > 0)
local wh = cfg.harass.wusage and CheckMana(cfg.harass.whmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) > 0)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana) and (CountEnemyHeroInRange(cfg.harass.erange, mh) > 0)
local mod = cfg.harass.mode
	if mod == 1 then
		if wh then CastSpell(_W, mh) end
		if eh then CastSpell(_E, mh) end
		if qh then CastSpell(_Q, mh) end
	elseif mod == 2 then
		if qh then CastSpell(_Q, mh) end
		if wh then CastSpell(_W, mh) end
		if eh then CastSpell(_E, mh) end
	end
end
function HarassJhin()
local qq = cfg.harass.qusage and CheckMana(cfg.harass.qmana)
local ww = cfg.harass.wusage and CheckMana(cfg.harass.wmana)
local ee = cfg.harass.eusage and CheckMana(cfg.harass.emana)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function HarassKassadin()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local wh = cfg.harass.wusage and CountEnemyHeroInRange(cfg.harass.whrange, mh) > 0
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana) and CountEnemyHeroInRange(cfg.harass.ehrange, mh) > 0
local mod = cfg.harass.mode
	if mod == 1 then
		if wh then CastSpell(_W, mh) end
		if eh then E:Cast(target) end
		if qh then Q:Cast(target) end
	elseif mod == 2 then
		if qh then Q:Cast(target) end
		if wh then CastSpell(_W, mh) end
		if eh then E:Cast(target) end
	end
end
function HarassKayle()
local qq = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local ww = cfg.harass.wusage and CheckMana(cfg.harass.whmana) and (CountEnemyHeroInRange(670, mh) > 0)
local ee = cfg.harass.eusage and CheckMana(cfg.harass.ehmana) and (CountEnemyHeroInRange(670, mh) > 0)
	if qq then Q:Cast(target) end
	if ww then CastSpell(_W, mh) end
	if ee then CastSpell(_E, mh) end
end
function HarassLissandra()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local wh = cfg.harass.wusage and CheckMana(cfg.harass.whmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) >= cfg.harass.wenemy)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana)
local mod = cfg.harass.mode
	if mod == 1 then
		if wh then CastSpell(_W, mh) end
		if qh then Q:Cast(target) end
		if eh then E:Cast(target) end
	elseif mod == 2 then
		if eh then E:Cast(target) end
		if qh then Q:Cast(target) end
		if wh then CastSpell(_W, mh) end
	end
end
function HarassNasus()
local qh = cfg.harass.qusage and CheckMana(cfg.harass.qmana) and (CountEnemyHeroInRange(mh.range+250, mh) > 0)
local wh = cfg.harass.wusage and CheckMana(cfg.harass.wmana)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.emana)
	if qh then CastSpell(_Q, mh) end
	if wh then W:Cast(target) end
	if eh then E:Cast(target) end
end
function HarassNunu()
local wh = cfg.harass.wusage and CheckMana(cfg.harass.whmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) > 0)
local eh = cfg.harass.eusage and CheckMana(cfg.harass.ehmana)
	if wh then CastSpell(_W, mh) end
	if eh then E:Cast(target) end
end
function HarassOrnn()
local qq = cfg.harass.qusage and CheckMana(cfg.harass.qmana)
local ww = cfg.harass.wusage and CheckMana(cfg.harass.wmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) > 0)
local ee = cfg.harass.eusage and CheckMana(cfg.harass.emana)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function HarassPantheon()
local qq = cfg.harass.qusage and CheckMana(cfg.harass.qhmana)
local ww = cfg.harass.wusage and CheckMana(cfg.harass.whmana)
local ee = cfg.harass.eusage and CheckMana(cfg.harass.ehmana) and (CountEnemyHeroInRange(cfg.combo.ehrange, mh) > 0)
	if qq then Q:Cast(target) end
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function HarassRammus()
local qqq = cfg.harass.qusage and CheckMana(cfg.harass.qmana) and (CountEnemyHeroInRange(cfg.harass.qrange, mh) > 0)
local www = cfg.harass.wusage and CheckMana(cfg.harass.wmana) and (CountEnemyHeroInRange(cfg.harass.wrange, mh) >= cfg.harass.wpeop)
local eee = cfg.harass.eusage and CheckMana(cfg.harass.emana)
	if qqq then CastSpell(_Q, mh) end
	if www then CastSpell(_W, mh) end
	if eee then E:Cast(target) end
end
function HarassSinged()
local ww = cfg.harass.wusage and CheckMana(cfg.harass.wmana)
local ee = cfg.harass.eusage and CheckMana(cfg.harass.emana)
	if ww then W:Cast(target) end
	if ee then E:Cast(target) end
end
function HarassTeemo()
local qq = cfg.harass.qhusage and CheckMana(cfg.harass.qhmana)
	if qq then Q:Cast(target) end
end
function HarassTristana()
local qq = cfg.harass.qhusage and (CountEnemyHeroInRange(cfg.harass.qhrange, mh) > 0)
	if qq then CastSpell(_Q, mh) end
end
function HarassVladimir()
local qq = cfg.harass.qusage
local ee = cfg.harass.eusage and CountEnemyHeroInRange(cfg.harass.ehrange, mh) > 0
local mod = cfg.harass.mode
	if mod == 1 then
		if qq then Q:Cast(target) end
		if ee then E:Cast(target) end
	elseif mod == 2 then
		if ee then E:Cast(target) end
		if qq then Q:Cast(target) end
	end
end


function ClearAkali()
local qqc = cfg.clear.qusage
local eec = cfg.clear.eusage
local qqj = cfg.jungle.qusage
local eej = cfg.jungle.eusage
	if qqc then Q:LaneClear() end
	if eec then E:LaneClear() end
	if qqj then Q:JungleClear() end
	if eej then E:JungleClear() end
end
function ClearAmumu()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearBlitzcrank()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearFizz()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearHecarim()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
	end
end
function ClearJhin()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearKassadin()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearKayle()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
		if qqc then Q:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
		if qqj then Q:JungleClear() end
	end
end
function ClearLissandra()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
		if qqc then Q:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
		if qqj then Q:JungleClear() end
	end
end
function ClearNasus()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearNunu()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearOrnn()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearPantheon()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local wwc = cfg.clear.wusage
	local eec = cfg.clear.eusage
		if qqc then Q:LaneClear() end
		if wwc then W:LaneClear() end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if qqj then Q:JungleClear() end
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearRammus()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
		if qqc then Q:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
		if qqj then Q:JungleClear() end
	end
end
function ClearShaco()
	if CheckMana(cfg.clear.mana) then
	local eec = cfg.clear.eusage
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local eej = cfg.jungle.eusage
		if eej then E:JungleClear() end
	end
end
function ClearSinged()
	if CheckMana(cfg.clear.mana) then
	local eec = cfg.clear.eusage
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local eej = cfg.jungle.eusage
		if eej then E:JungleClear() end
	end
end
function ClearTeemo()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
		if qqc then Q:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local qqj = cfg.jungle.qusage
		if qqj then Q:JungleClear() end
	end
end
function ClearTristana()
	if CheckMana(cfg.clear.mana) then
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
		if qqc then CastSpell(_Q, mh) end
		if eec then E:LaneClear() end
	end
	if CheckMana(cfg.jungle.mana) then
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage
		if wwj then W:JungleClear() end
		if eej then E:JungleClear() end
	end
end
function ClearVladimir()
	local qqc = cfg.clear.qusage
	local eec = cfg.clear.eusage
	local qqj = cfg.jungle.qusage
	local wwj = cfg.jungle.wusage
	local eej = cfg.jungle.eusage

		if qqc then Q:LaneClear() end
		if eec then E:LaneClear() end
		if qqj then Q:JungleClear() end
		if eej then E:JungleClear() end
end

function ComboItems()
local dist = CountEnemyHeroInRange(650, mh) > 0
	if cfg.items.ccut and CountEnemyHeroInRange(750, mh) > 0 then CastItem(3144, target) end
	if cfg.items.cbok and dist then CastItem(3153, target) end
	if cfg.items.cgun and dist then CastItem(3146, target) end
	if cfg.items.ctia and CountEnemyHeroInRange(175, mh) > 0 then
	CastItem(3077) CastItem(3074) CastItem(3748)
	end
end
function HarassItems()
local dist = CountEnemyHeroInRange(650, mh) > 0
	if cfg.items.hcut and CountEnemyHeroInRange(750, mh) > 0 then CastItem(3144, target) end
	if cfg.items.hbok and dist then CastItem(3153, target) end
	if cfg.items.hgun and dist then CastItem(3146, target) end
	if cfg.items.htia and CountEnemyHeroInRange(175, mh) > 0 then
	CastItem(3077) CastItem(3074) CastItem(3748)
	end
end
function PanicItems()
local panic = mh.health / mh.maxHealth < cfg.items.panic / 100
	if panic then
		if CountEnemyHeroInRange(750, mh) > 0 then CastItem(3144, target) end
		if dist then CastItem(3153, target) end
		if dist then CastItem(3146, target) end
		if CountEnemyHeroInRange(175, mh) > 0 then
		CastItem(3077) CastItem(3074) CastItem(3748)
		end
	end
end

function ClearItems() CastItem(3077) CastItem(3074)	CastItem(3748) end
function JungleItems() CastItem(3077) CastItem(3074) CastItem(3748) end

function ShacoTools()
	if cfg.moto.motousage then
		if cfg.moto.tred then mh:MoveTo(7800, 4000) end
		if cfg.moto.bred then mh:MoveTo(3600, 8000) end
		if cfg.moto.tblue then mh:MoveTo(3600, 8000) end
		if cfg.moto.bblue then mh:MoveTo(11000, 7000) end
		if cfg.moto.basekey then
			local blue = player.team == TEAM_BLUE
			if blue then
				mh:MoveTo(0,0)
			else
				mh:MoveTo(25000,25000)
			end
		end
	end
end
function AkaliTools()
local ww = cfg.wlo.wusage and (CountEnemyHeroInRange(cfg.wlo.wrange, mh) >= cfg.wlo.wauto )
local ra = cfg.combo.raim
local mod = cfg.wlo.mode
	if ra then R:Cast(target) end
	if ww then
		if mod == 1 then W:Cast(target)
		elseif mod == 2 then CastSpell(_W, mh)
		end
	end
end
function AmumuTools()
local ar = (CountEnemyHeroInRange(540, mh) >= cfg.auto.rautoe)
	if ar then CastSpell(_R, mh) end

local ae = cfg.auto.rauto and (CountEnemyHeroInRange(600, mh) >= cfg.auto.rautoe)
	if ae then CastSpell(_R, mh) end
end
function BlitzTools()
local ar = (CountEnemyHeroInRange(600, mh) > 0) and mh.health / mh.maxHealth < cfg.combo.panicr / 100
	if ar then CastSpell(_R, mh) end
local ae = cfg.auto.rauto and (CountEnemyHeroInRange(600, mh) >= cfg.auto.rautoe)
	if ae then CastSpell(_R, mh) end
end
function EvelynnTools()
local ea = cfg.combo.eaim
local ra = cfg.combo.raim
	if ea then E:Cast(target) end
	if ra then R:Cast(target) end
end
function FizzTools()
local ra = cfg.combo.raim
	if ra then R:Cast(target) end
end
function JhinTools()
local wa = cfg.combo.waim
local ra = cfg.combo.raim
	if wa then W:Cast(target) end
	if ra then R:Cast(target) end
end
function KayleTools()
local ra = cfg.combo.raim
local wa = cfg.combo.waim
	if ra then CastSpell(_R, mh) end
	if wa then CastSpell(_W, mh) end
end
function LissandraTools()
local panicr = (CountEnemyHeroInRange(600, mh) > 0) and mh.health / mh.maxHealth < cfg.combo.panicr / 100
local autow = cfg.combo.autow and (CountEnemyHeroInRange(445, mh) >= cfg.combo.wauto)
local ra = cfg.combo.raim
	if ra then R:Cast(target) end
    if panicr then CastSpell(_R, mh) end
	if autow then CastSpell(_W, mh) end
end
function NasusTools()
local ar = (CountEnemyHeroInRange(700, mh) > 0) and mh.health / mh.maxHealth < cfg.combo.rpanic / 100
local are = mh.health / mh.maxHealth < cfg.combo.rpanic / 100
	if cfg.combo.peop then
		if ar then CastSpell(_R, mh) end
	else
		if are then CastSpell(_R, mh) end
	end
end
function OrnnTools()
local ra = cfg.combo.raim
	if ra then R:Cast(target) end
end
function PantheonTools()
local ra = cfg.combo.raim
local ea = cfg.combo.eaim
	if ra then R:Cast(target) end
	if ea then E:Cast(target) end
end
function RammusTools()
local ra = cfg.auto.raim and (CountEnemyHeroInRange(350, mh) >= cfg.auto.rauto)
local wa = cfg.auto.waim and (CountEnemyHeroInRange(cfg.auto.wrange, mh) >= cfg.auto.wauto)
	if ra then CastSpell(_R, mh) end
	if wa then CastSpell(_W, mh) end
end
function TristanaTools()
local ra = cfg.combo.raim
	if ra then R:Cast(target) end
end
function VladimirTools()
local ww = (CountEnemyHeroInRange(600, mh) > 0) and mh.health / mh.maxHealth < cfg.combo.panicw / 100
	if ww then CastSpell(_W, mh) end
end

function OnTick()
if mh.dead then return end
target = GetTarget()
PanicItems()
	if OrbwalkManager:IsCombo() then
		if aka then ComboAkali()
		elseif amu then ComboAmumu()
		elseif blit then ComboBlitzcrank()
		elseif evel then ComboEvelynn()
		elseif fiz then ComboFizz()
		elseif heca then ComboHecarim()
		elseif jin then ComboJhin()
		elseif kasa then ComboKassadin()
		elseif kay then ComboKayle()
		elseif liss then ComboLissandra()
		elseif nas then ComboNasus()
		elseif nunu then ComboNunu()
		elseif orn then ComboOrnn()
		elseif pha then ComboPantheon()
		elseif ram then ComboRammus()
		elseif sha then ComboShaco()
		elseif sing then ComboSinged()
		elseif tem then ComboTeemo()
		elseif tri then ComboTristana()
		elseif vlad then ComboVladimir()
		end
		ComboItems()
	end
	if OrbwalkManager:IsHarass() then
		if aka then HarassAkali()
		elseif amu then HarassAmumu()
		elseif blit then HarassBlitzcrank()
		elseif evel then HarassEvelynn()
		elseif fiz then HarassFizz()
		elseif heca then HarassHecarim()
		elseif jin then HarassJhin()
		elseif kasa then HarassKassadin()
		elseif kay then HarassKayle()
		elseif liss then HarassLissandra()
		elseif nas then HarassNasus()
		elseif nunu then HarassNunu()
		elseif orn then HarassOrnn()
		elseif pha then HarassPantheon()
		elseif ram then HarassRammus()
		elseif sing then HarassSinged()
		elseif tem then HarassTeemo()
		elseif tri then HarassTristana()
		elseif vlad then HarassVladimir()
		end
		HarassItems()
	end
	if not evel then
	if OrbwalkManager:IsClear() then
		if aka then ClearAkali()
		elseif amu then ClearAmumu()
		elseif blit then ClearBlitzcrank()
		elseif fiz then ClearFizz()
		elseif heca then ClearHecarim()
		elseif jin then ClearJhin()
		elseif kasa then ClearKassadin()
		elseif kay then ClearKayle()
		elseif liss then ClearLissandra()
		elseif nas then ClearNasus()
		elseif nunu then ClearNunu()
		elseif orn then ClearOrnn()
		elseif pha then ClearPantheon()
		elseif ram then ClearRammus()
		elseif sha then ClearShaco()
		elseif sing then ClearSinged()
		elseif tem then ClearTeemo()
		elseif tri then ClearTristana()
		elseif vlad then ClearVladimir()
		end
		if cfg.jungle.use then JungleItems() end
		if cfg.clear.use then ClearItems() end
	end
	end
	if aka then AkaliTools()
	elseif amu then AmumuTools()
	elseif blit then BlitzTools()
	elseif evel then EvelynnTools()
	elseif fiz then FizzTools()
	elseif jin then JhinTools()
	elseif kay then KayleTools()
	elseif liss then LissandraTools()
	elseif nas then NasusTools()
	elseif orn then OrnnTools()
	elseif pha then PantheonTools()
	elseif ram then RammusTools()
	elseif sha then ShacoTools()
	elseif tri then TristanaTools()
	elseif vlad then VladimirTools()
	end
	if cfg.draw.resetsettings then
		cfg.draw.resetsettings = false
		cfg.draw.targetsize = 20
		cfg.draw.TargetX = 50
		cfg.draw.TargetY = 50
		if sha then
			local ido = cfg.sett.idioma
			if ido == 1 then
				print("Target Draw Settings are reset")
			end
			if ido == 2 then
				print("Los Dibujos del Objetivo han sido reseteados de posicion")
			end
			if ido == 3 then
				print("Els Dibuixos del Objectiu han set restablerts per defecte")
			end
		else
			print("Target Draw Settings are reset")
		end
	end
end

function GetTarget()
		TS = TargetSelector(TARGET_LESS_CAST_PRIORITY, 1200, DAMAGE_MAGIC)
	TS:update()
	return TS.target
end

function FixOnScreenTarget()
	if target then
	local size = cfg.draw.targetsize
	local ttx = cfg.draw.TargetX
	local tty = cfg.draw.TargetY
	local tc = target.charName
	local col = cfg.draw.targetcolor
		if sha then
		local ido = cfg.sett.idioma
			if ido == 1 then
				DrawTextA("Focus :  "..tc, size, ttx, tty, ARGB(tu(col)))
			end
			if ido == 2 then
				DrawTextA("Objetivo :  "..tc, size, ttx, tty, ARGB(tu(col)))
			end
			if ido == 3 then
				DrawTextA("Objectiu :  "..tc, size, ttx, tty, ARGB(tu(col)))
			end
		else
			DrawTextA("Focus :  "..tc, size, ttx, tty, ARGB(tu(col)))
		end
	end
end

function OnMouseTarget()
	if target then
	mym = GetCursorPos()
	local size = cfg.draw.targetsize
	local tc = target.charName
	local col = cfg.draw.targetcolor
		if sha then
		local ido = cfg.sett.idioma
			if ido == 1 then
				DrawTextA("Focus :  "..tc, size, mym.x-20, mym.y-20, ARGB(tu(col)))
			end
			if ido == 2 then
				DrawTextA("Objetivo :  "..tc, size, mym.x-20, mym.y-20, ARGB(tu(col)))
			end
			if ido == 3 then
				DrawTextA("Objectiu :  "..tc, size, mym.x-20, mym.y-20, ARGB(tu(col)))
			end
		else
			DrawTextA("Focus :  "..tc, size, mym.x-20, mym.y-20, ARGB(tu(col)))
		end
	end
end

class "_Required"
function _Required:__init()
    self.requirements = {}
    self.downloading = {}
    return self
end

function _Required:Add(t)
    assert(t and type(t) == "table", "_Required: table is invalid!")
    local name = t.Name
    assert(name and type(name) == "string", "_Required: name is invalid!")
    local url = t.Url
    assert(url and type(url) == "string", "_Required: url is invalid!")
    local extension = t.Extension ~= nil and t.Extension or "lua"
    local usehttps = t.UseHttps ~= nil and t.UseHttps or true
    table.insert(self.requirements, {Name = name, Url = url, Extension = extension, UseHttps = usehttps})
end

function _Required:Check()
    for i, tab in pairs(self.requirements) do
        local name = tab.Name
        local url = tab.Url
        local extension = tab.Extension
        local usehttps = tab.UseHttps
        if not FileExist(LIB_PATH..name.."."..extension) then
            print("Downloading a required library called "..name.. ". Please wait...")
            local d = _Downloader(tab)
            table.insert(self.downloading, d)
        end
    end

    if #self.downloading > 0 then
        for i = 1, #self.downloading, 1 do
            local d = self.downloading[i]
            AddTickCallback(function() d:Download() end)
        end
        self:CheckDownloads()
    else
        for i, tab in pairs(self.requirements) do
            local name = tab.Name
            local url = tab.Url
            local extension = tab.Extension
            local usehttps = tab.UseHttps
            if FileExist(LIB_PATH..name.."."..extension) and extension == "lua" then
                require(name)
            end
        end
    end
end

function _Required:CheckDownloads()
    if #self.downloading == 0 then
        print("Required libraries downloaded. Please reload with 2x F9.")
    else
        for i = 1, #self.downloading, 1 do
            local d = self.downloading[i]
            if d.GotScript then
                table.remove(self.downloading, i)
                break
            end
        end
        DelayAction(function() self:CheckDownloads() end, 2)
    end
end

function _Required:IsDownloading()
    return self.downloading ~= nil and #self.downloading > 0 or false
end

class "_Downloader"
function _Downloader:__init(t)
    local name = t.Name
    local url = t.Url
    local extension = t.Extension ~= nil and t.Extension or "lua"
    local usehttps = t.UseHttps ~= nil and t.UseHttps or true
    self.SavePath = LIB_PATH..name.."."..extension
    self.ScriptPath = '/BoL/TCPUpdater/GetScript'..(usehttps and '5' or '6')..'.php?script='..self:Base64Encode(url)..'&rand='..ran(99999999)
    self:CreateSocket(self.ScriptPath)
    self.DownloadStatus = 'Connect to Server'
    self.GotScript = false
end

function _Downloader:CreateSocket(url)
    if not self.LuaSocket then
        self.LuaSocket = require("socket")
    else
        self.Socket:close()
        self.Socket = nil
        self.Size = nil
        self.RecvStarted = false
    end
    self.Socket = self.LuaSocket.tcp()
    if not self.Socket then
        print('Socket Error')
    else
        self.Socket:settimeout(0, 'b')
        self.Socket:settimeout(99999999, 't')
        self.Socket:connect('sx-bol.eu', 80)
        self.Url = url
        self.Started = false
        self.LastPrint = ""
        self.File = ""
    end
end

function _Downloader:Download()
    if self.GotScript then return end
    self.Receive, self.Status, self.Snipped = self.Socket:receive(1024)
    if self.Status == 'timeout' and not self.Started then
        self.Started = true
        self.Socket:send("GET "..self.Url.." HTTP/1.1\r\nHost: sx-bol.eu\r\n\r\n")
    end
    if (self.Receive or (#self.Snipped > 0)) and not self.RecvStarted then
        self.RecvStarted = true
        self.DownloadStatus = 'Downloading Script (0%)'
    end

    self.File = self.File .. (self.Receive or self.Snipped)
    if self.File:find('</si'..'ze>') then
        if not self.Size then
            self.Size = tonumber(self.File:sub(self.File:find('<si'..'ze>')+6,self.File:find('</si'..'ze>')-1))
        end
        if self.File:find('<scr'..'ipt>') then
            local _,ScriptFind = self.File:find('<scr'..'ipt>')
            local ScriptEnd = self.File:find('</scr'..'ipt>')
            if ScriptEnd then ScriptEnd = ScriptEnd - 1 end
            local DownloadedSize = self.File:sub(ScriptFind+1,ScriptEnd or -1):len()
            self.DownloadStatus = 'Downloading Script ('..math.round(100/self.Size*DownloadedSize,2)..'%)'
        end
    end
    if self.File:find('</scr'..'ipt>') then
        self.DownloadStatus = 'Downloading Script (100%)'
        local a,b = self.File:find('\r\n\r\n')
        self.File = self.File:sub(a,-1)
        self.NewFile = ''
        for line,content in ipairs(self.File:split('\n')) do
            if content:len() > 5 then
                self.NewFile = self.NewFile .. content
            end
        end
        local HeaderEnd, ContentStart = self.NewFile:find('<sc'..'ript>')
        local ContentEnd, _ = self.NewFile:find('</scr'..'ipt>')
        if not ContentStart or not ContentEnd then
            if self.CallbackError and type(self.CallbackError) == 'function' then
                self.CallbackError()
            end
        else
            local newf = self.NewFile:sub(ContentStart+1,ContentEnd-1)
            local newf = newf:gsub('\r','')
            if newf:len() ~= self.Size then
                if self.CallbackError and type(self.CallbackError) == 'function' then
                    self.CallbackError()
                end
                return
            end
            local newf = Base64Decode(newf)
            if type(load(newf)) ~= 'function' then
                if self.CallbackError and type(self.CallbackError) == 'function' then
                    self.CallbackError()
                end
            else
                local f = io.open(self.SavePath,"w+b")
                f:write(newf)
                f:close()
                if self.CallbackUpdate and type(self.CallbackUpdate) == 'function' then
                    self.CallbackUpdate(self.OnlineVersion,self.LocalVersion)
                end
            end
        end
        self.GotScript = true
    end
end

function _Downloader:Base64Encode(data)
    local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    return ((data:gsub('.', function(x)
        local r,b='',x:byte()
        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
        return r;
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

function Update()
	if AUTOUPDATE then
		local ServerData = GetWebResult(UPDATE_HOST, "/RK1K/RKScriptFolder/master/RKHeross.version")
			if ServerData then
				ServerVersion = type(tonumber(ServerData)) == "number" and tonumber(ServerData) or nil
					if ServerVersion then
						if tonumber(version) < ServerVersion then
							DelayAction(function() print("<font color=\"#000000\"> | </font><font color=\"#FF0000\"><font color=\"#FFFFFF\">New version found for RK Heros... <font color=\"#000000\"> | </font><font color=\"#FF0000\"></font><font color=\"#FF0000\"><b> Version "..ServerVersion.."</b></font>") end, 3)
							DelayAction(function() print("<font color=\"#FFFFFF\"><b> >> Updating, please don't press F9 << </b></font>") end, 4)
							DelayAction(function() DownloadFile(UPDATE_URL, UPDATE_FILE_PATH, function () print("<font color=\"#000000\"> | </font><font color=\"#FF0000\"><font color=\"#FFFFFF\">RK Heros</font> <font color=\"#000000\"> | </font><font color=\"#FF0000\">UPDATED <font color=\"#FF0000\"><b>("..version.." => "..ServerVersion..")</b></font> Press F9 twice to load the updated version.") end) end, 5)
						else
							DelayAction(function() print("<b><font color=\"#000000\"> | </font><font color=\"#FF0000\"><font color=\"#FFFFFF\">RK Heros</font><font color=\"#000000\"> | </font><font color=\"#FF0000\"><font color=\"#FF0000\"> Version "..ServerVersion.."</b></font>") end, 1)
						end
					end
				else
			DelayAction(function() print("<font color=\"#FFFFFF\">RK Heros - Error while downloading version info, RE-DOWNLOAD MANUALLY.</font>")end, 1)
		end
	end
end
